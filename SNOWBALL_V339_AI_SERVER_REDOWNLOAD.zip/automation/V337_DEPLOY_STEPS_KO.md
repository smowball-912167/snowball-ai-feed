# 눈탱이 SNOWBALL AI FEED V337 설치 및 진단

## 기존 V336 성공 상태
- 기존 수동 실행: GitHub Actions `SNOWBALL V336 AI Feed (ZIP bootstrap)` 성공.
- 발행된 `docs/ai_discovery_feed.json`에서는 `scanned=24`, `completed=24`, `newsSignalCount=22`를 확인.
- 하지만 `officialChecked=0`, `officialNotConfigured=24`, `flowStatus=NOT_CONNECTED`, `verifiedRecommendations=[]`였음.

## V337 코드 변화
1. 기존 RSS 뉴스 수집, OpenDART/SEC 공시 관찰, 3갈래 분석 및 검사 유지.
2. 발급된 KRX OPEN API 키 + `유가증권 일별매매정보`, `코스닥 일별매매정보` 서비스 이용 승인이 있을 경우, 한국 종목의 *전 시장 합산 거래대금 순위*, 거래대금(원), 시가총액(원), 최근 영업일별 요약을 수집.
3. KRX 데이터는 다음 영업일 오전 8시 이후 공개되는 통계의 일부이며, 장중/실시간 정보가 아님. 국내 공휴일·API 갱신 지연에 따라 `PARTIAL`/`UNAVAILABLE` 허용.
4. 외국인·기관/연기금 종목별 순매수는 이 KRX OPEN API에 없음. `flowStatus=NOT_CONNECTED`, `verifiedRecommendations=[]` 유지. 실재하지 않는 외국인 순매수를 생성하지 않음.
5. GitHub Actions ZIP 재압축 해제 때 이전 `docs/ai_discovery_history.json`을 초기화하는 V336 문제 방지(V337 ZIP에서 feed/history 파일 자체를 제외).
6. 누출된 인증키·수급 확인 오인·검증되지 않은 AI 추천 승격 등을 별도 검증.

## 휴대전화 GitHub 배포: 기존 V336 ZIP / 앱 삭제 금지
- (1) `snowball-ai-feed` 저장소 최상위 **Code → Add file → Upload files**에서 `SNOWBALL_AI_FEED_V337_GITHUB_UPLOAD.zip` **한 개** 업로드 후 Commit.
- (2) `.github/workflows/snowball-ai.yml` 파일을 열어 **Edit**에서 내용을 `snowball-ai-v337.yml` 전체 내용으로 교체하고 Commit. **다른 경로에 새 워크플로를 만들지 말 것**. 기존 파일을 덮어써야 예약 실행이 중복되지 않음.
- (3) **Actions → SNOWBALL V337 AI Feed (ZIP bootstrap) → Run workflow**, main, 실행.
- (4) 초록색 Success 후 `Code → docs → ai_discovery_feed.json` 위쪽에 `marketDailySummary`, `officialChecked`, `officialNotConfigured`, `verifiedRecommendations` 값을 확인.
- (5) **API 키가 없다면** KRX 상태는 `NOT_CONFIGURED`, OpenDART는 `not_configured`임. 자동 수집 오류가 아니라 **인증 연결 전 단계**임.

## OpenDART 설정 (권장 순서 1)
1. 금융감독원 [OpenDART](https://opendart.fss.or.kr/) 회원가입/로그인 후 개발자 API 인증키(40자리) 발급.
2. GitHub `snowball-ai-feed → Settings → Secrets and variables → Actions → New repository secret`.
3. Name은 **`DART_API_KEY`**, Secret은 발급된 **40자리 값**. 저장.
4. `Actions → SNOWBALL V337 AI Feed (ZIP bootstrap) → Run workflow` 수동 실행.
5. 이제 `officialChecked`가 증가했는지 확인. OpenDART에서 검출된 공시 **접수 사실**이지 계약 실질/금액/투자 호재의 검증을 의미하지 않음.
6. API 키를 **채팅/스크린샷/코드/README/ZIP에 적지 말 것**. 사용자 계정·원장·보유 내역은 여전히 업로드하지 말 것.

## KRX OPEN API 설정 (선택, 권장 순서 2)
1. [KRX OPEN API](https://openapi.krx.co.kr/)에서 인증키 발급 후 **'유가증권 일별매매정보'와 '코스닥 일별매매정보' 두 서비스 별도 이용 승인**을 받아야 함.
2. 같은 GitHub Actions Repository secrets에 **`KRX_API_KEY`**로 등록.
3. V337 재실행. `marketDailySummary.status=OK` 또는 `PARTIAL`이고 한국 종목 `marketDaily.status=ok`이면 통계 데이터 이용 가능.
4. 키가 있어도 서비스 승인이 없으면 `UNAVAILABLE`. 위 상태를 외국인/기관 매수로 해석하지 말 것.
5. KRX 데이터 이용약관과 출처 표시 확인. 공개 feed는 원천 전체 시장 데이터가 아닌 지정 종목의 요약 통계만 발행.

## SEC EDGAR 설정 (선택)
- 미국 공식 SEC 데이터 조회를 위해 SEC 정책에 맞는 사용자 식별 문자열을 GitHub Secret **`SEC_USER_AGENT`**에 넣음. 예: `Your Research Team <your_real_email@example.com>` (실제 이름/이메일로 대체).
- 연락처는 깃허브 공개 소스에 저장하면 안 됨.

## 데이터 한계 및 기존 앱 보호
- `verifiedRecommendations=[]`은 버그라기보다 **추천 심사 보류**임. 뉴스 제목/공시 접수/거래대금으로만 추천할 수 없음.
- 한국 16개/미국 8개 표본 수집. 전 시장 자동 발굴로 과장하지 않음.
- 사용자가 기존에 설치한 눈탱이 앱/APK 소스를 이번 **서버 ZIP만으로 수정하거나 자동 연동할 수 없음**. 앱과 데이터 보전 및 서명키는 기존대로 유지.
- 3년/5년/10년 후 주도테마 확정과 월 2건 투자 추천은 미구현. 무리하게 가짜 신호 생성하지 않음.

## 공식 원문
- [OpenDART 공시검색](https://opendart.fss.or.kr/guide/detail.do?apiGrpCd=DS001&apiId=2019001)
- [OpenDART 기업고유번호](https://opendart.fss.or.kr/guide/detail.do?apiGrpCd=DS001&apiId=2019018)
- [KRX OPEN API 서비스 목록](https://openapi.krx.co.kr/contents/OPP/INFO/service/OPPINFO004.cmd)
- [KRX OPEN API 이용](https://openapi.krx.co.kr/contents/OPP/USES/service/OPPUSES002_S2.cmd?BO_ID=JvJFzlAENzZlPBDNGAWC)
- [SEC EDGAR API](https://www.sec.gov/edgar/sec-api-documentation)
