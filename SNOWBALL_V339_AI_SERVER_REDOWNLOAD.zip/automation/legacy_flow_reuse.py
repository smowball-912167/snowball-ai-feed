#!/usr/bin/env python3
"""V338: import a bounded *user-exported summary* from the existing SNOWBALL app.

This module deliberately NEVER contacts NAVER, TOSS or KRX: the legacy app's
existing collector is the single owner. Public outputs are observations only.
The source snapshot is opt-in, never bundled with the upload ZIP or created by
this server. An absent source is an honest NOT_CONNECTED state.
"""
from __future__ import annotations
from datetime import datetime, timezone, date, timedelta
from pathlib import Path
import json
import os
import re

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / 'private_input' / 'legacy_flow_summary.json'
MAX_BYTES = 150_000
SOURCE_TYPES = {'KRX_CSV', 'LEGACY_MIXED_CACHE'}
METRICS = ('foreign', 'institution', 'individual')
WINDOWS = (3, 5, 20)


def _datetime(value):
    if not isinstance(value, str): raise ValueError('INVALID_TIMESTAMP')
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if result.tzinfo is None: raise ValueError('NAIVE_TIMESTAMP')
        return result.astimezone(timezone.utc)
    except (TypeError, ValueError) as exc:
        raise ValueError('INVALID_TIMESTAMP') from exc


def _signed_qty(value):
    if type(value) is not int or abs(value) > 100_000_000_000:
        raise ValueError('INVALID_QUANTITY')
    return value


def _clean_rows(payload, now):
    if not isinstance(payload, dict) or payload.get('schema') != 'snowball.legacy_flow_summary.v1':
        raise ValueError('INVALID_SCHEMA')
    if set(payload) - {'schema', 'generatedAt', 'scope', 'stocks'}:
        raise ValueError('UNEXPECTED_PRIVATE_FIELDS')
    generated = _datetime(payload.get('generatedAt'))
    if generated > now + timedelta(minutes=10) or generated < now - timedelta(days=90):
        raise ValueError('EXPORT_TIMESTAMP_OUT_OF_BOUNDS')
    rows = payload.get('stocks')
    if not isinstance(rows, list) or len(rows) > 100: raise ValueError('INVALID_STOCK_COUNT')
    parsed = {}
    for item in rows:
        if not isinstance(item, dict): raise ValueError('INVALID_STOCK_RECORD')
        if set(item) != {'code', 'source', 'asOfDate', 'tradingDays', 'windows'}:
            raise ValueError('UNEXPECTED_STOCK_FIELDS')
        code = item.get('code')
        if not isinstance(code, str) or not re.fullmatch(r'[0-9]{6}', code):
            raise ValueError('INVALID_STOCK_CODE')
        if code in parsed: raise ValueError('DUPLICATE_STOCK_CODE')
        source = item.get('source')
        if source not in SOURCE_TYPES: raise ValueError('UNKNOWN_SOURCE')
        asof = item.get('asOfDate')
        try:
            if not isinstance(asof, str) or not re.fullmatch(r'20\d\d-\d\d-\d\d', asof): raise ValueError()
            obs_day = date.fromisoformat(asof)
        except ValueError as exc: raise ValueError('INVALID_OBSERVATION_DATE') from exc
        age = (now.date() - obs_day).days
        if age < -1 or age > 3660: raise ValueError('OBSERVATION_DATE_OUT_OF_BOUNDS')
        sessions = item.get('tradingDays')
        if type(sessions) is not int or not 1 <= sessions <= 3400:
            raise ValueError('INVALID_SESSION_COUNT')
        window_obj = item.get('windows')
        if not isinstance(window_obj, dict): raise ValueError('INVALID_WINDOWS')
        if set(window_obj) - {'3', '5', '20'}: raise ValueError('UNEXPECTED_WINDOWS')
        normalized = {}
        for period in WINDOWS:
            raw = window_obj.get(str(period))
            if raw is None: continue
            if sessions < period or not isinstance(raw, dict): raise ValueError('WINDOW_WITHOUT_SESSIONS')
            if set(raw.keys()) != set(METRICS): raise ValueError('INVALID_WINDOW_METRICS')
            normalized[str(period)] = {metric:_signed_qty(raw[metric]) for metric in METRICS}
        if not normalized or (sessions >= 3 and '3' not in normalized):
            raise ValueError('MISSING_WINDOWS')
        # A manually shared cache summary is not licensed raw feed and not
        # independently source-authenticated. Only very recent values observed.
        freshness = 'fresh' if 0 <= age <= 7 and now-generated <= timedelta(hours=72) else 'stale'
        parsed[code] = {'status': 'observed_unverified' if freshness == 'fresh' else 'stale',
                        'source': source, 'asOfDate': asof, 'tradingDays': sessions,
                        'windows': normalized, 'freshness': freshness,
                        'confidence': 'local_cache_export_unverified', 'units': 'shares'}
    return parsed


def enrich_legacy_flow(candidates, now=None, *, path=None, environ=None):
    now = now or datetime.now(timezone.utc)
    path = Path(path) if path is not None else DEFAULT_INPUT
    environ = environ if environ is not None else os.environ
    output = [dict(row) for row in candidates]
    summary = {'status':'NOT_CONNECTED','source':'SNOWBALL_APP_LEGACY_CACHE_EXPORT',
               'availableStocks':0,'freshStocks':0,'staleStocks':0,
               'automaticSync':False,'verifiedInvestorFlow':False,
               'note':'기존 앱 캐시의 사용자가 내보낸 요약만 재사용. 네트워크 재수집 없음. 매수추천 근거 확정 아님.'}
    for row in output:
        row['investorFlow'] = {'status': 'not_connected' if row.get('market') == 'KR' else 'not_applicable'}
    if not path.exists(): return summary, output
    if environ.get('SNOWBALL_FLOW_PUBLICATION_APPROVED','').lower() not in ('1','true','yes'):
        summary['status']='PUBLICATION_NOT_APPROVED'
        summary['note']='이전 앱 수급 데이터 제공자 재배포·파생 데이터 이용범위 승인 전 공개 출력 차단'
        return summary, output
    if not path.is_file() or path.stat().st_size > MAX_BYTES:
        summary['status'] = 'INVALID_INPUT'
        summary['errorType'] = 'INVALID_SIZE'
        return summary, output
    try:
        records = _clean_rows(json.loads(path.read_text(encoding='utf-8')), now)
    except (ValueError, TypeError, UnicodeDecodeError, OSError) as exc:
        summary['status'] = 'INVALID_INPUT'
        summary['errorType'] = str(exc)[:60] if isinstance(exc, ValueError) else type(exc).__name__
        return summary, output
    applied = set()
    for row in output:
        if row.get('market') != 'KR': continue
        code = str(row.get('code', ''))
        if code not in records: continue
        applied.add(code)
        row['investorFlow'] = dict(records[code])
    fresh = sum(row['investorFlow']['status'] == 'observed_unverified' for row in output if row.get('market') == 'KR')
    stale = sum(row['investorFlow']['status'] == 'stale' for row in output if row.get('market') == 'KR')
    summary.update({'status': 'OBSERVED_UNVERIFIED' if fresh else 'STALE' if stale else 'NO_MATCH',
                    'availableStocks': len(applied), 'freshStocks': fresh, 'staleStocks': stale})
    return summary, output
