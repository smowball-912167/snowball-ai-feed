#!/usr/bin/env python3
"""Scheduled PUBLIC NEWS discovery only; not an investment recommender.

No portfolio info, user login, securities account, API keys, or personal data.
No recommendations are generated until independent official/financial/flow gates exist.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone, timedelta
from email.utils import parsedate_to_datetime
import html
import json
import os
from pathlib import Path
import re
import time
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

from official_filings import enrich
from three_track_pipeline import build_tracks
from market_daily import enrich_market
from legacy_flow_reuse import enrich_legacy_flow

ROOT = Path(__file__).resolve().parents[1]
UNIVERSE = ROOT / "automation" / "scout_universe.json"
OUTPUT = ROOT / "docs" / "ai_discovery_feed.json"
HISTORY = ROOT / "docs" / "ai_discovery_history.json"
ACTION = re.compile(r"수주|공급계약|납품|양산|매출|영업이익|증설|생산|상용화|허가|승인|투자|실적|수출|계약|원전|반도체|로봇|방산|production|contract|earnings|orders|approval|revenue|manufactur|partnership|factory|shipment|award|expansion|guidance", re.I)
RUMOR = re.compile(r"찌라시|루머|소문|추측|\brumou?r(?:ed|ing|s)?\b|unconfirmed|unverified|speculation", re.I)
XML_TAG = re.compile(r"<[^>]*>")


def utcnow():
    return datetime.now(timezone.utc)


def clean(x):
    return html.unescape(XML_TAG.sub("", x or "")).strip()


def normalize(x):
    return re.sub(r"[\s·._\-–—＆&()（）]", "", (x or "").lower())


def matching(title, company):
    aliases = company.get("aliases") or [company["name"]]
    if company["code"] == "011790":
        return bool(re.search(r"(?<![A-Za-z0-9])SKC(?![A-Za-z0-9])", title, re.I))
    return any(normalize(a) in normalize(title) for a in aliases if len(normalize(a)) >= 3)


def parse_item(el, company, now):
    title = clean(el.findtext("title"))
    url = (el.findtext("link") or "").strip()
    pubdate = (el.findtext("pubDate") or "").strip()
    src = el.find("source")
    publisher = clean(src.text if src is not None else "") or "출처 미확인"
    try:
        when = parsedate_to_datetime(pubdate)
        if not when.tzinfo:
            when = when.replace(tzinfo=timezone.utc)
        when = when.astimezone(timezone.utc)
    except (ValueError, TypeError, OverflowError):
        return None
    if not (now - timedelta(days=120) <= when <= now + timedelta(hours=12)):
        return None
    if not matching(title, company) or not ACTION.search(title) or RUMOR.search(title):
        return None
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname:
        return None
    return {"title": title[:240], "url": url[:850], "date": when.date().isoformat(), "publisher": publisher[:90]}


def fetch_one(company, now, *, opener=urlopen):
    alias = company.get("aliases", [company["name"]])[0]
    query = f'"{alias}" when:90d'
    url = 'https://news.google.com/rss/search?' + urlencode({
        'q': query, 'hl': 'ko' if company['market'] == 'KR' else 'en-US',
        'gl': 'KR' if company['market'] == 'KR' else 'US',
        'ceid': 'KR:ko' if company['market'] == 'KR' else 'US:en'
    })
    req = Request(url, headers={'User-Agent': 'SNOWBALL/1.0 (public news research)', 'Accept': 'application/rss+xml,application/xml'})
    with opener(req, timeout=12) as response:
        raw = response.read(600001)
        if len(raw) > 600000:
            raise ValueError('RSS_RESPONSE_TOO_LARGE')
    root = ET.fromstring(raw)
    items = root.findall('.//channel/item')[:45]
    hits, seen = [], set()
    for item in items:
        v = parse_item(item, company, now)
        if v is None:
            continue
        dedupe = v['url'].split('?')[0]
        if dedupe in seen:
            continue
        seen.add(dedupe)
        hits.append(v)
    dates = {x['date'] for x in hits}
    pubs = {x['publisher'] for x in hits if x['publisher'] != '출처 미확인'}
    qualified = len(hits) >= 2 and len(dates) >= 2 and len(pubs) >= 2
    return {'code': company['code'], 'name': company['name'], 'market': company['market'],
            'theme': company['theme'], 'searchStatus': 'ok', 'received': len(items),
            'matches': len(hits), 'stage': 'news_signal' if qualified else 'insufficient',
            'evidence': hits[:5]}


def scan(now=None, *, opener=urlopen, universe=None, pause=0.4):
    now = now or utcnow()
    universe = universe if universe is not None else json.loads(UNIVERSE.read_text(encoding='utf-8'))
    candidates, errors = [], []
    for i, company in enumerate(universe):
        try:
            candidates.append(fetch_one(company, now, opener=opener))
        except Exception as exc:
            kind = type(exc).__name__
            candidates.append({'code': company['code'], 'name': company['name'],
                               'market': company['market'], 'theme': company['theme'],
                               'searchStatus': 'error', 'received': 0, 'matches': 0,
                               'stage': 'unavailable', 'evidence': [], 'error': kind})
            errors.append({'code': company['code'], 'type': kind})
        if pause and i < len(universe) - 1:
            time.sleep(pause)
    ok = sum(c['searchStatus'] == 'ok' for c in candidates)
    status = 'error' if ok == 0 else 'partial' if errors else 'ok'
    # Offline-safe official evidence: never promotes articles into verified recommendations.
    candidates = enrich(candidates, now, opener=opener, environ=os.environ)
    official_ok = sum(c['official']['status'] == 'ok' for c in candidates)
    official_missing = sum(c['official']['status'] == 'not_configured' for c in candidates)
    official_errors = sum(c['official']['status'] == 'error' for c in candidates)
    identifier_missing = sum(c['official']['status'] == 'identifier_missing' for c in candidates)
    filing_count = sum(len(c['official']['filings']) for c in candidates)
    market_summary, candidates = enrich_market(candidates, now, opener=opener, environ=os.environ)
    flow_summary, candidates = enrich_legacy_flow(candidates, now)
    tracks = build_tracks(candidates, now.isoformat(timespec='seconds').replace('+00:00', 'Z'))
    return {'schema': 'snowball.ai_discovery.v1', 'generatedAt': now.isoformat(timespec='seconds').replace('+00:00', 'Z'),
            'status': status, 'scanned': len(universe), 'completed': ok,
            'newsSignalCount': sum(c['stage'] == 'news_signal' for c in candidates),
            'scope': 'curated_public_news_seeds_KR_US',
            'officialChecked': official_ok, 'officialNotConfigured': official_missing,
            'officialFilingCount': filing_count, 'officialErrorCount': official_errors,
            'officialIdentifierMissing': identifier_missing, 'flowStatus': flow_summary['status'], 'legacyFlowSummary': flow_summary,
            'marketDailySummary': market_summary,
            'verification': 'NEWS_AND_OFFICIAL_FILINGS_UNREVIEWED', 'verifiedRecommendations': [],
            'candidates': candidates, 'errors': errors,
            'analysisTracks': tracks, 'recommendationReview': tracks['recommendationReview'],
            'note': '뉴스·공시·거래대금(선택적)과 기존 앱 수급 캐시 요약(선택적)을 관찰. 캐시 수급은 출처 재검증 전이며 재무·선반영·수급 확정 검증 전. 투자 추천 아님.'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', default=str(OUTPUT))
    ap.add_argument('--universe', default=str(UNIVERSE))
    ap.add_argument('--history', default=str(HISTORY))
    ap.add_argument('--no-pause', action='store_true', help='For local/mock tests only')
    args = ap.parse_args()
    universe = json.loads(Path(args.universe).read_text(encoding='utf-8'))
    data = scan(universe=universe, pause=0 if args.no_pause else 0.4)
    path = Path(args.output); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp'); tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8'); tmp.replace(path)
    hp = Path(args.history)
    try:
        history = json.loads(hp.read_text(encoding='utf-8'))
        if not isinstance(history, list): history = []
    except (OSError, ValueError):
        history = []
    history.append({'at': data['generatedAt'], 'status': data['status'], 'scanned': data['scanned'],
                    'completed': data['completed'], 'newsSignals': data['newsSignalCount']})
    hp.parent.mkdir(parents=True, exist_ok=True)
    hp.write_text(json.dumps(history[-120:], ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"{data['generatedAt']} scanned={data['scanned']} successful={data['completed']} status={data['status']}")
    # Fail loudly if every query failed; keep diagnostic output but don't pretend zero articles means zero candidates.
    return 1 if data['status'] == 'error' else 0


if __name__ == '__main__':
    raise SystemExit(main())
