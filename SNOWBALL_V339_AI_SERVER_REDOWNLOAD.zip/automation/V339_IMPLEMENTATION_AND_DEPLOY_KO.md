# 눈탱이 V339 공개 AI 피드 서버 수정

- 기존 V338 NEWS/DART/SEC/KRX 재사용 수집 엔진과 기존 수급 단일 소유권 유지.
- automation/recommendation_gate_v339.py가 공식 원문·발행일·언론/AI 출처·희석·밸류에이션·현금흐름·수급·독립 검토 기록을 형식 검증하고 언론 2 + 자체 1 이하로 선정함.
- automation/three_track_pipeline.py가 모든 수집 후보에 해당 검증을 실행하며 결과를 recommendationReview에 기록함.
- 현재 피드에는 공식 공시/재무/수급 독립 검증 자료가 없는 종목이 있어 추천 통과 0건이 정상임. 뉴스 제목만으로 매수 추천하지 않음. verifiedRecommendations는 기존대로 비워둠.
- 기존 docs/ai_discovery_feed.json 및 history 파일은 ZIP에 넣지 않음. 공개 GitHub 저장소의 기존 결과/히스토리 보호.
- 외부 데이터 검증은 데이터 내용/이용권한까지 별도 확인해야 하며 스키마 통과만으로 투자 적합성을 확정하지 않음.
