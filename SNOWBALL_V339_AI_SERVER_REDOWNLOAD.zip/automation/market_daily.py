#!/usr/bin/env python3
"""Optional KRX daily trade statistics for shortlisted Korean equities.

KRX OPEN API stock daily services: market volume, turnover and market cap only.
They DO NOT provide stock-level institutional/foreign-investor net buying.
Never report this data as investor flows or a completed recommendation gate.
No KRX API key or unlicensed raw market dataset is ever placed in the public feed.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
import os
import re
from urllib.parse import urlencode
from urllib.request import Request, urlopen

HOST = "https://data-dbg.krx.co.kr"
ENDPOINTS = ("stk_bydd_trd", "ksq_bydd_trd")
KST = timezone(timedelta(hours=9))


def _number(value):
    value = str(value).replace(",", "").strip()
    if not re.fullmatch(r"\d{1,20}", value):
        raise ValueError("KRX_NUMBER_INVALID")
    return int(value)


def _request_day(service, day, key, *, opener):
    if service not in ENDPOINTS or not re.fullmatch(r"\d{8}", day):
        raise ValueError("INVALID_KRX_QUERY")
    url = HOST + "/svc/apis/sto/" + service + "?" + urlencode({"basDd": day})
    req = Request(url, headers={"AUTH_KEY": key, "User-Agent": "SNOWBALL/1.0 public-market-observation", "Accept": "application/json"})
    with opener(req, timeout=15) as response:
        raw = response.read(2_500_001)
    if len(raw) > 2_500_000:
        raise ValueError("KRX_RESPONSE_TOO_LARGE")
    obj = json.loads(raw)
    if not isinstance(obj, dict) or not isinstance(obj.get("OutBlock_1"), list):
        raise ValueError("KRX_RESPONSE_INVALID_OR_NOT_AUTHORIZED")
    rows = obj["OutBlock_1"]
    parsed = {}
    for x in rows:
        if not isinstance(x, dict) or x.get("BAS_DD") != day:
            continue
        code = str(x.get("ISU_CD", "")).strip()
        if not re.fullmatch(r"\d{6}", code):
            continue
        try:
            turnover = _number(x.get("ACC_TRDVAL"))
            cap = _number(x.get("MKTCAP"))
            volume = _number(x.get("ACC_TRDVOL"))
        except ValueError:
            continue
        parsed[code] = {"turnoverKRW": turnover, "marketCapKRW": cap, "volume": volume}
    return parsed


def _recent_business_days(now, limit=12):
    local = now.astimezone(KST)
    # Settlement data is not normally available until the NEXT BUSINESS DAY 08:00 KST.
    # Never use unconfirmed same-day trading data.
    current = local.date() - timedelta(days=1 if local.hour >= 8 else 2)
    for i in range(limit):
        d = current - timedelta(days=i)
        if d.weekday() < 5:
            yield d.strftime("%Y%m%d")


def enrich_market(candidates, now=None, *, opener=urlopen, environ=None, session_limit=3):
    """Return (summary, copied/enriched candidates) with correctly scoped KRX stats.

    All publication remains *observation only*. On missing entitlement, service error,
    holiday or partial market data, never invent zero turnover or rank.
    """
    now = now or datetime.now(timezone.utc)
    environ = environ if environ is not None else os.environ
    key = environ.get("KRX_API_KEY", "").strip()
    output = [dict(x) for x in candidates]
    summary = {"status": "NOT_CONFIGURED", "source": "KRX OPEN API", "marketDataSessions": 0, "attribution": "한국거래소 통계정보",
               "coveredKoreanStocks": 0, "investorFlowIncluded": False,
               "note": "거래대금·시총·거래량만 제공. 외국인·기관·연기금 수급 데이터 아님."}
    for row in output:
        row["marketDaily"] = {"status": "not_configured" if row.get("market") == "KR" else "not_applicable", "source": "KRX OPEN API"}
    if not key:
        return summary, output
    if not re.fullmatch(r"[A-Za-z0-9]{20,100}", key):
        summary["status"] = "INVALID_CONFIGURATION"
        for row in output:
            if row.get("market") == "KR": row["marketDaily"]["status"] = "invalid_configuration"
        return summary, output

    sessions = []
    errors = set()
    for day in _recent_business_days(now):
        if len(sessions) >= session_limit:
            break
        markets = []
        for service in ENDPOINTS:
            try:
                part = _request_day(service, day, key, opener=opener)
                if part: markets.append(part)
                else: errors.add("NO_ROWS")
            except Exception as e:
                errors.add(type(e).__name__)
        # Whole-market rank is only meaningful when BOTH KOSPI and KOSDAQ exist.
        if len(markets) != len(ENDPOINTS):
            continue
        joined = {**markets[0], **markets[1]}
        ranked = sorted(joined.items(), key=lambda x: (-x[1]["turnoverKRW"], x[0]))
        rank = {code: i + 1 for i, (code, _) in enumerate(ranked)}
        sessions.append((day, joined, rank))
    if not sessions:
        summary["status"] = "UNAVAILABLE"
        summary["errorTypes"] = sorted(errors)
        for row in output:
            if row.get("market") == "KR": row["marketDaily"]["status"] = "unavailable"
        return summary, output

    covered = 0
    for row in output:
        if row.get("market") != "KR": continue
        code = row.get("code")
        observations = []
        for day, all_stocks, ranks in sessions:
            if code in all_stocks:
                data = all_stocks[code]
                observations.append({"date": f"{day[:4]}-{day[4:6]}-{day[6:]}",
                                     "turnoverKRW": data["turnoverKRW"],
                                     "marketCapKRW": data["marketCapKRW"],
                                     "marketTurnoverRank": ranks[code]})
        if not observations:
            row["marketDaily"] = {"status": "identifier_missing", "source": "KRX OPEN API"}
            continue
        covered += 1
        row["marketDaily"] = {"status": "ok", "source": "KRX OPEN API",
                              "observations": observations, "asOfDate": observations[0]["date"],
                              "turnoverKRW": observations[0]["turnoverKRW"],
                              "marketCapKRW": observations[0]["marketCapKRW"],
                              "marketTurnoverRank": observations[0]["marketTurnoverRank"]}
    summary.update({"status": "OK" if len(sessions) == session_limit and not errors else "PARTIAL",
                    "marketDataSessions": len(sessions), "coveredKoreanStocks": covered})
    if errors: summary["errorTypes"] = sorted(errors)
    return summary, output
