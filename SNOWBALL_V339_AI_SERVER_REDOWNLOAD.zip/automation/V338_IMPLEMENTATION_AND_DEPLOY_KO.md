# 눈탱이 V338 — 중복수집 방지의 실제 코드 구현

## 이번 작업에서 구현한 것

- **이전 앱 원본 유지:** V336 전체 소스에서 기존 V60 NAVER/V139 KRX CSV/V145 TOSS 및 누적수급, 원장, 뉴스 관련 기능을 직접 확인함. 기존 `v51-live-linked-all` 스크립트의 SHA-256을 잠가 변경 또는 대체되면 회귀 검사에서 차단함.
- **실제 재사용 경로:** 안드로이드 소스의 기술분석 화면에 **기존 수급 데이터 내보내기** 버튼을 추가. 별도 스크래핑 없이 로컬 `snowball_v60_verified_flow_XXXXXX`, `snowball_v139_krx_flow_XXXXXX` 캐시만 읽어 3/5/20거래일 외국인·기관·개인 순매수 요약을 만들고 사용자가 눌렀을 때만 공유. 안드로이드 브리지는 코드/날짜/수급기간/정수 값만 화이트리스트로 재검증함.
- **서버측 수신:** `automation/legacy_flow_reuse.py`는 앱이 내보낸 요약 파일만 읽음. NAVER·TOSS·KRX 재호출 없음. 오류, 자료 없음, 오래된 자료를 구분하며 검증되지 않은 관측값은 AI 추천으로 승격하지 않음.
- **중복 수집 차단:** `automation/source_registry_v338.json`, `tools/check_collector_reuse.py`, `tools/check_server_registry_v338.py`가 소스 단일 소유자·원본 해시·새 수급 조회 금지·기존 가이드 원문 동일성을 자동 검사함.
- **원문 동기화:** `tools/sync_master_app_guide.py` 실행 후 `NOONTANGI_MASTER_MANUAL_V70.html`, `app/src/main/assets/NOONTANGI_MASTER_MANUAL_V70.html`, 앱 내 `nt293FullMasterManual` 세 본문이 바이트 단위 일치함. 기존 앱 가이드/접힘 내용은 삭제하지 않음.

## 실행 상태 및 제한

1. V338은 **소스 파일과 자동 테스트가 준비된 상태**입니다. **GitHub에 배포된 것도, 휴대폰 APK로 새로 빌드·서명되어 설치된 것도 아닙니다.** 기존 V336 서버는 그대로 운영하세요.
2. 휴대폰에 보관된 로컬 수급 데이터는 GitHub Actions에서 자동 접근할 수 없습니다. 실제로 서버에서 읽으려면 V338 앱 버전에서 요약 파일을 내보내고, 해당 데이터를 적법하고 안전하게 서버 입력으로 제공하는 과정이 필요합니다.
3. 외부 시세·수급 제공자의 재배포 조건을 확인하기 전에는 요약 파일을 **공개 GitHub 저장소에 업로드하지 마세요**. 데이터가 필요한 경우 비공개 GitHub Actions secret `SNOWBALL_LEGACY_FLOW_B64`에 요약 JSON의 base64 값을 보관하도록 지원하되, 이 과정도 사용자가 직접 승인해야 합니다. 또한 원천 이용권한 확인 후 Repository variable `SNOWBALL_FLOW_PUBLICATION_APPROVED=1`을 설정하지 않으면 서버는 `PUBLICATION_NOT_APPROVED`로 표시하고 공개 피드에 어떠한 수급 요약값도 기록하지 않습니다. 서버는 이를 일시적인 작업 디렉토리(`private_input/`)에 복원하고 공개 Git에 커밋하지 않습니다.
4. 3/5/20거래일 양수 수급이 나와도 `observed_unverified`로만 표기합니다. KRX 공식 출처와 거래대금·공시·재무·선반영·라이선스 조건을 독립적으로 검증하기 전 확정 AI 종목 추천 0건을 유지합니다.
5. Android SDK와 원래 서명키 기반 실제 APK 빌드 및 갤럭시 실기기 실행은 이번 소스 단위 검증 범위 밖입니다. 새 APK를 기존 설치본에 덮어써서 사용자 데이터가 손실되는 일이 없도록 기존 패키지를 보존합니다.

## 서버를 배포하려면 (사용자가 승인한 뒤)

- `SNOWBALL_AI_FEED_V338_GITHUB_UPLOAD.zip`을 `snowball-ai-feed` 저장소 최상단에 올립니다.
- 기존 `.github/workflows/snowball-ai.yml` **한 개만** 다운로드한 `snowball-ai-v338.yml` 내용으로 교체합니다. 두 워크플로를 동시에 활성화하지 않습니다.
- Actions → `SNOWBALL V338 AI Feed (ZIP bootstrap)` → Run workflow. 최초에는 보통 `flowStatus: NOT_CONNECTED`가 정상입니다. 기존 뉴스 RSS 공시 조회는 계속 수행됩니다.
- 저장소 Settings → Actions → General의 workflow write permission이 필요할 수 있습니다. Secrets는 GitHub에만 보관하고 채팅에 입력하지 마세요.

## 회귀 테스트

- Python V333~V337 (7개) + V338 (2개) + JS V338 (1개) + 통합·수집 소유자 검사 (2개): 총 **12개 테스트/게이트** 로컬 통과.
- 빌드 전 `python tools/sync_master_app_guide.py && python tools/check_collector_reuse.py` 실행.
- 서버 실행 전 `python tools/check_server_registry_v338.py`, 기타 테스트, 출력 JSON 검증 실행.

## 변경하지 않은 항목

앱 패키지 ID, 서명, 계좌 분류와 수동거래 원장, 투자 점수와 종목 보유, 기존 수급 차트/외부 조회, 기존 AI 추천 삭제 이력, 뉴스 원문·번역·읽기, 기존 GitHub V336 운영 상태.
