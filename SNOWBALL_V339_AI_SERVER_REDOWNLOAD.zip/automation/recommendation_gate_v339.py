"""SNOWBALL V339: conservative 2+1 *review* gate, not automatic trade advice.

Media: at most 2, independent AI: at most 1. All evidence must be linkable,
recent and independently reviewed. This validates *submitted evidence structure*;
it cannot prove an issuer's claims or live valuation and never issues orders.
"""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse
import re

LIMITS = {'media': 2, 'independent': 1}
SOURCE_HOSTS = ('dart.fss.or.kr', 'opendart.fss.or.kr', 'kind.krx.co.kr',
                'www.sec.gov', 'sec.gov', 'data.krx.co.kr', 'www.krx.co.kr', 'ecos.bok.or.kr')
REVIEW_AXES = ('dilution', 'valuation', 'cashFlow', 'flow')


def _date(value, now, days):
    try:
        d = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        if d.tzinfo is None: d = d.replace(tzinfo=timezone.utc)
        return now - timedelta(days=days) <= d.astimezone(timezone.utc) <= now + timedelta(hours=12)
    except (ValueError, TypeError, OverflowError):
        return False


def _url(value, official=False):
    if not isinstance(value, str) or len(value) > 1200: return False
    try:
        u = urlparse(value)
        if u.scheme != 'https' or not u.hostname or u.username or u.password or u.port: return False
        if official and u.hostname.lower() not in SOURCE_HOSTS: return False
        return bool(u.netloc and u.path)
    except (ValueError, TypeError):
        return False


def _identity(item):
    if not isinstance(item, dict): return ''
    market, code = str(item.get('market','')).upper(), str(item.get('code','')).upper()
    if (market == 'KR' and re.fullmatch(r'\d{6}',code)) or (market == 'US' and re.fullmatch(r'[A-Z]{1,6}(?:\.[A-Z])?',code)):
        return market + ':' + code
    return ''


def validate_candidate(item, *, now=None):
    now = now or datetime.now(timezone.utc)
    errors=[]
    ident=_identity(item)
    if not ident: errors.append('invalid_market_or_code')
    if not isinstance(item,dict): return errors
    if not isinstance(item.get('name'),str) or not (1 <= len(item['name'].strip()) <= 90): errors.append('invalid_name')
    kind=item.get('sourceType')
    if kind not in LIMITS: errors.append('invalid_source_type')
    if not _date(item.get('sourceDate'),now,45): errors.append('source_date_missing_or_stale')
    if kind=='media':
        m=item.get('mediaEvidence') or {}
        if not (isinstance(m,dict) and len(str(m.get('publisher','')).strip())>=2 and
                len(str(m.get('title','')).strip())>=8 and _url(m.get('url')) and
                _date(m.get('publishedAt'),now,45)):
            errors.append('media_recommendation_not_documented')
    if kind=='independent':
        a=item.get('aiDiscovery') or {}
        if not (isinstance(a,dict) and len(str(a.get('method','')).strip())>=12 and
                len(str(a.get('reason','')).strip())>=30):
            errors.append('ai_method_and_reason_missing')
    e=item.get('officialEvidence') or {}
    if not (isinstance(e,dict) and _url(e.get('url'),official=True) and
            _date(e.get('publishedAt'),now,550) and len(str(e.get('claim','')).strip())>=15):
        errors.append('official_evidence_not_verified')
    review=item.get('riskReview') or {}
    if not isinstance(review,dict): review={}
    for axis in REVIEW_AXES:
        field=review.get(axis) or {}
        window = 10 if axis=='flow' else 185
        if not (isinstance(field,dict) and field.get('status')=='pass' and
                _url(field.get('sourceUrl'),official=True) and
                _date(field.get('asOf'),now,window) and
                len(str(field.get('finding','')).strip())>=15):
            errors.append('unverified_'+axis)
    approval=item.get('reviewApproval') or {}
    if not (isinstance(approval,dict) and approval.get('status')=='independently_checked' and
            _date(approval.get('checkedAt'),now,10) and
            len(str(approval.get('auditTrail','')).strip())>=18):
        errors.append('independent_review_missing')
    return errors


def select_2plus1(candidates, previous=(), *, now=None):
    now = now or datetime.now(timezone.utc)
    previous_keys=set()
    for row in previous or ():
        if isinstance(row,str):
            previous_keys.add(row.upper())
        else:
            ident=_identity(row)
            if ident: previous_keys.add(ident)
    selected={'media':[],'independent':[]}
    rejected=[]
    seen=set()
    for row in candidates if isinstance(candidates,list) else []:
        ident=_identity(row)
        if not ident:
            rejected.append({'code':str(row.get('code','')) if isinstance(row,dict) else '', 'reasons':['invalid_market_or_code']})
            continue
        if ident in seen or ident in previous_keys or ident.split(':')[-1] in previous_keys:
            rejected.append({'code':ident,'reasons':['duplicate_or_previously_recommended']});continue
        seen.add(ident)
        errors=validate_candidate(row,now=now)
        if errors:
            rejected.append({'code':ident,'reasons':errors});continue
        group=row['sourceType']
        if len(selected[group])>=LIMITS[group]:
            rejected.append({'code':ident,'reasons':['quota_filled']});continue
        selected[group].append({'market':row['market'], 'code':row['code'], 'name':row['name'],
                                'sourceType':group, 'status':'evidence_gate_passed_final_review_required',
                                'officialEvidence':row['officialEvidence'], 'riskReview':row['riskReview']})
    return {'schema':'snowball.recommendation_review.v339',
            'limits':dict(LIMITS), 'selected':selected,
            'counts':{k:len(v) for k,v in selected.items()},
            'rejected':rejected,
            'publicationStatus':'REVIEW_GATE_ONLY_NOT_A_TRADE_RECOMMENDATION'}
