#!/usr/bin/env python3
"""V337 validation, extending all V336 safety and non-promotion requirements."""
from __future__ import annotations
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from validate_v336_published_feed import validate as validate_v336


def validate(feed, *, now=None):
    errors = list(validate_v336(feed, now=now))
    summary = feed.get('marketDailySummary')
    if not isinstance(summary, dict):
        errors.append('market_daily_summary_missing')
        summary = {}
    if summary.get('source') != 'KRX OPEN API': errors.append('market_daily_source_missing')
    if summary.get('attribution') != '한국거래소 통계정보': errors.append('market_daily_attribution_missing')
    if summary.get('status') not in ('NOT_CONFIGURED', 'INVALID_CONFIGURATION', 'UNAVAILABLE', 'PARTIAL', 'OK'):
        errors.append('market_daily_status_unknown')
    if summary.get('investorFlowIncluded') is not False: errors.append('market_daily_falsely_claims_flow')
    if feed.get('flowStatus') != 'NOT_CONNECTED': errors.append('investor_flow_falsely_connected')
    if feed.get('verification') != 'NEWS_AND_OFFICIAL_FILINGS_UNREVIEWED': errors.append('verification_changed')
    candidates = feed.get('candidates') if isinstance(feed.get('candidates'),list) else []
    observed = 0
    official_ok = 0
    official_missing = 0
    official_errors = 0
    official_id_missing = 0
    filing_total = 0
    for c in candidates:
        if not isinstance(c,dict): continue
        official = c.get('official') or {}
        market = c.get('marketDaily') or {}
        if official.get('status') not in ('ok', 'not_configured', 'error', 'identifier_missing'):
            errors.append('official_status_invalid')
        if official.get('status') == 'ok': official_ok += 1
        if official.get('status') == 'not_configured': official_missing += 1
        if official.get('status') == 'error': official_errors += 1
        if official.get('status') == 'identifier_missing': official_id_missing += 1
        if not isinstance(official.get('filings'),list): errors.append('filing_list_invalid')
        else:
            filing_total += len(official['filings'])
            if official.get('status') != 'ok' and official['filings']: errors.append('filing_without_valid_source')
        if c.get('investorFlow',{}).get('status') != 'not_connected': errors.append('false_investor_flow_connected')
        if c.get('recommendationStatus') != 'not_verified': errors.append('unverified_candidate_promoted')
        if c.get('market') == 'US':
            if market.get('status') != 'not_applicable':errors.append('krx_applied_to_us')
            continue
        if market.get('status') not in ('not_configured','invalid_configuration','unavailable','identifier_missing','ok'):
            errors.append('market_daily_invalid_status')
        if market.get('status') == 'ok':
            observed += 1
            if market.get('source') != 'KRX OPEN API':errors.append('market_daily_invalid_source')
            if not (isinstance(market.get('marketTurnoverRank'),int) and market['marketTurnoverRank'] > 0):
                errors.append('market_daily_invalid_rank')
            if not (isinstance(market.get('turnoverKRW'),int) and market['turnoverKRW'] >= 0):
                errors.append('market_daily_invalid_turnover')
            if not (isinstance(market.get('marketCapKRW'),int) and market['marketCapKRW'] >= 0):
                errors.append('market_daily_invalid_cap')
            if not isinstance(market.get('observations'),list) or not 1 <= len(market['observations']) <= 3:
                errors.append('market_daily_invalid_observations')
    if len(candidates) > 0:
        for field, expected in [('officialChecked',official_ok),('officialNotConfigured',official_missing),
                                ('officialErrorCount',official_errors),('officialIdentifierMissing',official_id_missing),
                                ('officialFilingCount',filing_total)]:
            if feed.get(field) != expected:errors.append(field+'_count_mismatch')
    if summary.get('coveredKoreanStocks') != observed: errors.append('market_coverage_count_mismatch')
    if summary.get('status') in ('NOT_CONFIGURED','INVALID_CONFIGURATION','UNAVAILABLE') and observed:
        errors.append('market_source_false_unavailable')
    # A public feed may contain KRX summarized observations, never secret/credential fields.
    raw = json.dumps(feed,ensure_ascii=False)
    for forbidden in ('KRX_API_KEY','AUTH_KEY','SEC_USER_AGENT','DART_API_KEY','appsecret','access_token', 'refresh_token'):
        if '"'+forbidden+'"' in raw:errors.append('credential_leak_'+forbidden)
    return sorted(set(errors))


def main():
    path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('docs/ai_discovery_feed.json')
    try: feed=json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError) as exc:
        print('FAIL unable_to_read_feed',type(exc).__name__);return 1
    bad=validate(feed)
    for e in bad:print('FAIL',e)
    if bad:return 1
    print('PASS V337: official source, daily market stats, privacy, and strict unrecommended status')
    return 0

if __name__=='__main__':raise SystemExit(main())
