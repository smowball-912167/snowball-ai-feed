#!/usr/bin/env python3
"""Offline KRX mock tests. The fabricated numbers NEVER leave the test runner."""
import io, json, sys
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'automation'))
import market_daily as m

NOW=datetime(2026,11,13,1,0,tzinfo=timezone.utc) # 10 AM KST; previous session is 12th
KEY='B'*40
DAYS=['20261112','20261111','20261110']

class Resp(io.BytesIO):pass

def fake(req,timeout):
    assert timeout==15
    assert req.get_header('Auth_key')==KEY
    url=urlparse(req.full_url)
    assert url.hostname=='data-dbg.krx.co.kr'
    d=parse_qs(url.query)['basDd'][0]
    if d not in DAYS: return Resp(json.dumps({'OutBlock_1':[]}).encode())
    service=url.path.rsplit('/',1)[-1]
    def item(code,turnover):
        return {'ISU_CD':code,'BAS_DD':d,'ACC_TRDVAL':f'{turnover:,}', 'MKTCAP':'1,500,000,000,000','ACC_TRDVOL':'2,000,000'}
    if service=='stk_bydd_trd':
        data=[item('011790',400_000_000_000), item('005930',600_000_000_000)]
    else:
        data=[item('247540',300_000_000_000), item('042700',200_000_000_000)]
    return Resp(json.dumps({'OutBlock_1':data}).encode())

seed=[{'code':'011790','market':'KR','name':'SKC','investorFlow':{'status':'not_connected'}},
      {'code':'247540','market':'KR','name':'EcoPro','investorFlow':{'status':'not_connected'}},
      {'code':'NVDA','market':'US','name':'NVIDIA','investorFlow':{'status':'not_connected'}}]
summary,out=m.enrich_market(seed,NOW,opener=fake,environ={'KRX_API_KEY':KEY})
assert summary['status']=='OK' and summary['marketDataSessions']==3 and summary['coveredKoreanStocks']==2,summary
assert summary['investorFlowIncluded'] is False
assert out[0]['marketDaily']['marketTurnoverRank']==2
assert out[0]['marketDaily']['turnoverKRW']==400_000_000_000
assert len(out[0]['marketDaily']['observations'])==3
assert out[1]['marketDaily']['marketTurnoverRank']==3
assert out[2]['marketDaily']['status']=='not_applicable'
assert all(x['investorFlow']['status']=='not_connected' for x in out)
assert 'B'*40 not in json.dumps(out,ensure_ascii=False)

summary,out=m.enrich_market(seed,NOW,opener=fake,environ={})
assert summary['status']=='NOT_CONFIGURED' and summary['coveredKoreanStocks']==0
assert all(x['marketDaily']['status']=='not_configured' for x in out[:2])

summary,out=m.enrich_market(seed,NOW,opener=fake,environ={'KRX_API_KEY':'bad'})
assert summary['status']=='INVALID_CONFIGURATION'

def broken(req,timeout):raise TimeoutError('timeout')
summary,out=m.enrich_market(seed,NOW,opener=broken,environ={'KRX_API_KEY':KEY})
assert summary['status']=='UNAVAILABLE' and all(x['marketDaily']['status']=='unavailable' for x in out[:2])

assert m._number('1,200,350')==1200350
for invalid in ('', '-1', 'not data', '10.5'):
    try:m._number(invalid);raise AssertionError(invalid)
    except ValueError:pass
print('PASS V337: KRX dates, full-market ranks, valid response, unavailable and secret safety')
