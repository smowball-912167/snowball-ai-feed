#!/usr/bin/env python3
"""GitHub server-only release gate (does not require full Android source)."""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
registry=json.loads((ROOT/'automation/source_registry_v338.json').read_text(encoding='utf-8'))
required={
    'app-legacy-investor-flow':('KR.stock.investor_net_shares','app/src/main/assets/index.html#v51-live-linked-all'),
    'server-market-turnover':('KR.stock.daily_turnover_marketcap','automation/market_daily.py'),
    'server-news-observation':('KR_US.stock.public_news_headlines','automation/ai_discovery_collector.py'),
    'server-official-filing':('KR_US.stock.official_filing_submission','automation/official_filings.py'),
}
errors=[];seen=set()
for x in registry.get('sources',[]):
    entry=(x.get('scope'),x.get('owner'))
    if x.get('id') not in required or entry!=required[x['id']]:errors.append('unapproved_data_collector')
    if x.get('scope') in seen:errors.append('duplicate_scope')
    seen.add(x.get('scope'))
if {x.get('id') for x in registry.get('sources',[])}!=set(required):errors.append('owner_registry_missing')
code=(ROOT/'automation/legacy_flow_reuse.py').read_text(encoding='utf-8')
for token in ('urlopen','requests.get','urllib.request','httpx.','fetch_one('):
    if token in code:errors.append('duplicated_network_collector:'+token)
collector=(ROOT/'automation/ai_discovery_collector.py').read_text(encoding='utf-8')
if 'from legacy_flow_reuse import enrich_legacy_flow' not in collector or 'flow_summary, candidates = enrich_legacy_flow(candidates, now)' not in collector:
    errors.append('legacy_importer_not_wired')
if 'private_input' not in code:errors.append('private_source_boundary_missing')
allowed=set(registry.get('approvedServerNetworkModules',[]))
if allowed!={'automation/ai_discovery_collector.py','automation/market_daily.py','automation/official_filings.py'}:
    errors.append('network_allowlist_changed')
for module in (ROOT/'automation').glob('*.py'):
    rel=module.relative_to(ROOT).as_posix()
    code=module.read_text(encoding='utf-8')
    if rel not in allowed and any(token in code for token in ('from urllib.request import','import requests','import httpx','urlopen(','build_opener(','requests.get(','requests.post(')):
        errors.append('unregistered_new_network_module:'+rel)
if errors:
    for e in errors:print('FAIL',e)
    sys.exit(1)
print('PASS V338 SERVER: unique registered owners and legacy investor-flow read-only adapter')
