#!/usr/bin/env python3
"""Offline end-to-end: real app summary -> server collector -> strict validator."""
from pathlib import Path
from datetime import datetime, timezone
from unittest.mock import patch
import io, json, os, sys, tempfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'automation'))
sys.path.insert(0,str(Path(__file__).resolve().parent))
import ai_discovery_collector as a
import legacy_flow_reuse
from validate_v338_published_feed import validate
NOW=datetime(2026,11,13,1,0,tzinfo=timezone.utc)
RSS=b'''<?xml version="1.0"?><rss><channel>
<item><title>SKC signed supply contract</title><link>https://news.google.com/rss/abc</link><pubDate>Thu, 12 Nov 2026 01:00:00 GMT</pubDate><source>A</source></item>
<item><title>SKC begins factory production</title><link>https://news.google.com/rss/def</link><pubDate>Wed, 11 Nov 2026 01:00:00 GMT</pubDate><source>B</source></item>
</channel></rss>'''

def opener(req,timeout):
    assert req.full_url.startswith('https://news.google.com/'), 'unexpected_network_call:'+req.full_url
    return io.BytesIO(RSS)

SEED=[{'code':'011790','name':'SKC','market':'KR','theme':'materials','aliases':['SKC']}]
DOC={'schema':'snowball.legacy_flow_summary.v1','generatedAt':NOW.isoformat().replace('+00:00','Z'),
     'scope':'public_market_flow_only_no_account_data','stocks':[
       {'code':'011790','source':'KRX_CSV','asOfDate':'2026-11-12','tradingDays':22,
        'windows':{'3':{'foreign':12,'institution':13,'individual':-25},
                   '5':{'foreign':19,'institution':25,'individual':-44},
                   '20':{'foreign':39,'institution':-2,'individual':-37}}}]}
with tempfile.TemporaryDirectory() as tmp:
    file=Path(tmp)/'legacy_flow_summary.json';file.write_text(json.dumps(DOC),encoding='utf-8')
    with patch.object(legacy_flow_reuse,'DEFAULT_INPUT',file), patch.dict(os.environ,{'DART_API_KEY':'','SEC_USER_AGENT':'','KRX_API_KEY':'','SNOWBALL_FLOW_PUBLICATION_APPROVED':'1'}):
        feed=a.scan(NOW,opener=opener,universe=SEED,pause=0)
    assert feed['flowStatus']=='OBSERVED_UNVERIFIED',feed['legacyFlowSummary']
    assert feed['candidates'][0]['investorFlow']['windows']['3']['foreign']==12
    assert feed['analysisTracks']['aiReviewQueue'][0]['checks']['investorFlow']=='observed_unverified'
    assert feed['verifiedRecommendations']==[]
    assert validate(feed,now=NOW)==[],validate(feed,now=NOW)
    tampered=json.loads(json.dumps(feed));tampered['candidates'][0]['investorFlow']['confidence']='verified'
    assert 'legacy_flow_falsely_verified' in validate(tampered,now=NOW)
    tampered=json.loads(json.dumps(feed));tampered['verifiedRecommendations']=[{'code':'011790'}]
    assert 'legacy_flow_promoted_recommendations' in validate(tampered,now=NOW)
    tampered=json.loads(json.dumps(feed));tampered['legacyFlowSummary']['automaticSync']=True
    assert 'legacy_flow_falsely_approved' in validate(tampered,now=NOW)
print('PASS V338 full integration: old collector, legacy source, published observation and rejection gates')
