#!/usr/bin/env python3
"""Regression cases: actual inherited app summary, stale, invalid, no file, no secrets."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import sys, json, tempfile, os
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'automation'))
from legacy_flow_reuse import enrich_legacy_flow
from three_track_pipeline import build_tracks

NOW=datetime(2026,11,13,2,0,tzinfo=timezone.utc)
KR={'code':'011790','market':'KR','name':'SKC','theme':'반도체','stage':'news_signal','matches':4,'evidence':[],'official':{'status':'not_configured','filings':[]}}
US={'code':'NVDA','market':'US','name':'NVIDIA','theme':'반도체','stage':'insufficient','matches':0,'evidence':[],'official':{'status':'not_configured','filings':[]}}
CAND=[KR,US]
EXPORT={'schema':'snowball.legacy_flow_summary.v1','generatedAt':NOW.isoformat().replace('+00:00','Z'),'stocks':[
    {'code':'011790','source':'KRX_CSV','asOfDate':'2026-11-12','tradingDays':27,'windows':{
        '3':{'foreign':900,'institution':1100,'individual':-2000},
        '5':{'foreign':1400,'institution':1800,'individual':-3200},
        '20':{'foreign':1200,'institution':-500,'individual':-700}}}]}
os.environ['SNOWBALL_FLOW_PUBLICATION_APPROVED']='1'
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'summary.json'
    s,rows=enrich_legacy_flow(CAND,NOW,path=p)
    assert s['status']=='NOT_CONNECTED' and rows[0]['investorFlow']['status']=='not_connected'
    p.write_text(json.dumps(EXPORT),encoding='utf-8')
    blocked,blocked_rows=enrich_legacy_flow(CAND,NOW,path=p,environ={})
    assert blocked['status']=='PUBLICATION_NOT_APPROVED' and blocked_rows[0]['investorFlow']['status']=='not_connected'
    s,rows=enrich_legacy_flow(CAND,NOW,path=p)
    assert s['status']=='OBSERVED_UNVERIFIED' and s['freshStocks']==1
    assert rows[0]['investorFlow']['windows']['5']['foreign']==1400
    assert rows[0]['investorFlow']['confidence']=='local_cache_export_unverified'
    assert rows[1]['investorFlow']['status']=='not_applicable'
    t=build_tracks(rows,NOW.isoformat())
    assert t['verifiedRecommendations']==[] and t['confirmedLeaders']==[]
    assert t['aiReviewQueue'][0]['checks']['investorFlow']=='observed_unverified'
    stale=json.loads(json.dumps(EXPORT));stale['stocks'][0]['asOfDate']='2026-10-05'
    p.write_text(json.dumps(stale));s,rows=enrich_legacy_flow(CAND,NOW,path=p)
    assert s['status']=='STALE' and rows[0]['investorFlow']['status']=='stale'
    for bad in (dict(EXPORT,stocks=[EXPORT['stocks'][0],EXPORT['stocks'][0]]),
                dict(EXPORT,stocks=[dict(EXPORT['stocks'][0],windows={'3':{'foreign':900,'institution':'800','individual':-1700}})]),
                dict(EXPORT,stocks=[dict(EXPORT['stocks'][0],source='TOSS_NEW_SCRAPER')]),
                dict(EXPORT,account_number='foo',stocks=[dict(EXPORT['stocks'][0],code='AB1234')])):
        p.write_text(json.dumps(bad));s,rows=enrich_legacy_flow(CAND,NOW,path=p)
        assert s['status']=='INVALID_INPUT' and rows[0]['investorFlow']['status']=='not_connected',s
print('PASS V338 legacy flow: missing/fresh/stale/invalid/duplicates/privacy and no AI promotions')
