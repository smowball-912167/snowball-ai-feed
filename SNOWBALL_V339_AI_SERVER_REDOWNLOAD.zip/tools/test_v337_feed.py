#!/usr/bin/env python3
"""Offline validator regression tests; no real requests or fabricated investment picks."""
import sys
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'automation'))
from validate_v337_published_feed import validate
from three_track_pipeline import build_tracks
NOW=datetime(2026,11,13,1,0,tzinfo=timezone.utc)
ISO=NOW.isoformat().replace('+00:00','Z')
ROW={'code':'011790','name':'SKC','market':'KR','theme':'materials','searchStatus':'ok','stage':'insufficient',
     'evidence':[], 'matches':0, 'official':{'status':'not_configured','filings':[]},
     'investorFlow':{'status':'not_connected'},'recommendationStatus':'not_verified',
     'marketDaily':{'status':'not_configured','source':'KRX OPEN API'}}
SUMMARY={'status':'NOT_CONFIGURED','source':'KRX OPEN API','attribution':'한국거래소 통계정보','marketDataSessions':0,
         'coveredKoreanStocks':0,'investorFlowIncluded':False}
FEED={'schema':'snowball.ai_discovery.v1','generatedAt':ISO,'status':'ok','scanned':1,'completed':1,
      'verifiedRecommendations':[],'flowStatus':'NOT_CONNECTED','candidates':[ROW],
      'verification':'NEWS_AND_OFFICIAL_FILINGS_UNREVIEWED','officialChecked':0,'officialNotConfigured':1,
      'officialFilingCount':0,'officialErrorCount':0,'officialIdentifierMissing':0,
      'marketDailySummary':SUMMARY,'analysisTracks':build_tracks([ROW],ISO)}
assert not validate(FEED,now=NOW),validate(FEED,now=NOW)
assert 'market_daily_falsely_claims_flow' in validate({**FEED,'marketDailySummary':{**SUMMARY,'investorFlowIncluded':True}},now=NOW)
assert 'investor_flow_falsely_connected' in validate({**FEED,'flowStatus':'CONNECTED'},now=NOW)
assert 'credential_leak_KRX_API_KEY' in validate({**FEED,'KRX_API_KEY':'DONT_USE'},now=NOW)
assert 'officialNotConfigured_count_mismatch' in validate({**FEED,'officialNotConfigured':0},now=NOW)
print('PASS V337: feed safety, source gates, official counts, no false investor signals')
