#!/usr/bin/env python3
"""V338 strict public output validation; legacy flow remains unverified observation."""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import json
import sys
from validate_v337_published_feed import validate as previous

VALID_FLOW = {'NOT_CONNECTED','PUBLICATION_NOT_APPROVED','INVALID_INPUT','OBSERVED_UNVERIFIED','STALE','NO_MATCH'}
VALID_CAND = {'not_connected','not_applicable','observed_unverified','stale'}


def validate(feed, *, now=None):
    now = now or datetime.now(timezone.utc)
    errors = []
    summary = feed.get('legacyFlowSummary')
    if not isinstance(summary, dict):
        errors.append('legacy_flow_summary_missing');summary={}
    state = summary.get('status')
    if state not in VALID_FLOW or feed.get('flowStatus') != state:
        errors.append('legacy_flow_status_mismatch')
    if summary.get('source') != 'SNOWBALL_APP_LEGACY_CACHE_EXPORT':
        errors.append('legacy_flow_source_invalid')
    if summary.get('automaticSync') is not False or summary.get('verifiedInvestorFlow') is not False:
        errors.append('legacy_flow_falsely_approved')
    a = summary.get('availableStocks')
    f = summary.get('freshStocks')
    s = summary.get('staleStocks')
    if not all(type(x) is int and x>=0 for x in (a,f,s)):
        errors.append('legacy_flow_counts_invalid')
    feed_copy = deepcopy(feed)
    feed_copy['flowStatus'] = 'NOT_CONNECTED'
    candidates = feed.get('candidates') if isinstance(feed.get('candidates'), list) else []
    copied = feed_copy.get('candidates', [])
    observed = stale = 0
    for idx,c in enumerate(candidates):
        if not isinstance(c,dict):continue
        row = c.get('investorFlow')
        if not isinstance(row,dict) or row.get('status') not in VALID_CAND:
            errors.append('legacy_flow_candidate_invalid');continue
        st=row['status']
        if c.get('market')!='KR' and st!='not_applicable': errors.append('legacy_flow_applied_outside_korea')
        if c.get('market')=='KR' and st=='not_applicable': errors.append('legacy_flow_bad_missing_state')
        if st in ('observed_unverified','stale'):
            observed += (st=='observed_unverified');stale += (st=='stale')
            if row.get('source') not in ('KRX_CSV','LEGACY_MIXED_CACHE'):
                errors.append('legacy_flow_untrusted_source')
            if row.get('confidence')!='local_cache_export_unverified' or row.get('units')!='shares':
                errors.append('legacy_flow_falsely_verified')
            windows=row.get('windows')
            if not isinstance(windows,dict):errors.append('legacy_flow_windows_missing')
            else:
                for k,v in windows.items():
                    if k not in ('3','5','20') or not isinstance(v,dict) or set(v.keys())!={'foreign','institution','individual'} or any(type(x)!=int or abs(x)>100_000_000_000 for x in v.values()):
                        errors.append('legacy_flow_windows_invalid')
            if not isinstance(row.get('asOfDate'),str):errors.append('legacy_flow_asof_missing')
        if idx<len(copied): copied[idx]['investorFlow']={'status':'not_connected'}
    if isinstance(f,int) and f!=observed: errors.append('legacy_flow_fresh_count_mismatch')
    if isinstance(s,int) and s!=stale: errors.append('legacy_flow_stale_count_mismatch')
    if isinstance(a,int) and a!=observed+stale: errors.append('legacy_flow_coverage_mismatch')
    if state=='OBSERVED_UNVERIFIED' and observed==0: errors.append('legacy_flow_false_connected')
    if state=='NOT_CONNECTED' and (observed or stale): errors.append('legacy_flow_false_disconnected')
    # Run all V336-V337 controls without weakening the existing gates.
    errors.extend(previous(feed_copy, now=now))
    if feed.get('verifiedRecommendations')!=[]:errors.append('legacy_flow_promoted_recommendations')
    return sorted(set(errors))


def main():
    p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('docs/ai_discovery_feed.json')
    try: feed=json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError) as exc:
        print('FAIL cannot_read_feed',type(exc).__name__);return 1
    bad=validate(feed)
    for v in bad:print('FAIL',v)
    if bad:return 1
    print('PASS V338: old validators + real-app-flow observation-only, privacy, no fake promotions')
    return 0

if __name__=='__main__':raise SystemExit(main())
