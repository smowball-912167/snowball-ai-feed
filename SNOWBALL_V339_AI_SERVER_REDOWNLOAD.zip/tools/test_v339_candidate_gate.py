import unittest, sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'automation'))
from recommendation_gate_v339 import validate_candidate, select_2plus1
NOW=datetime(2026,11,14,tzinfo=timezone.utc)

def fixture(code='000001',type='media'):
    return {'market':'KR','code':code,'name':'테스트기업','sourceType':type,'sourceDate':'2026-11-13',
     'mediaEvidence':{'publisher':'테스트 언론','title':'구체적인 기업 분석 결과 및 실적 평가','url':'https://example.org/recommendation','publishedAt':'2026-11-13'},
     'aiDiscovery':{'method':'공식 전자공시 자료 교차검증 분석','reason':'신규 매출과 실제 수주 및 현금흐름 개선 근거를 공식 공시 기준으로 교차 점검'},
     'officialEvidence':{'url':'https://dart.fss.or.kr/dsaf001/main.do?rcpNo=20261113000001','publishedAt':'2026-11-13','claim':'매출과 현금흐름 개선 근거를 원문에서 점검'},
     'riskReview':{k:{'status':'pass','sourceUrl':'https://data.krx.co.kr/contents/MDI/MAIN/main/index.cmd','asOf':'2026-11-13','finding':'원자료 날짜와 해석을 명시하며 교차 검증함'} for k in ('dilution','valuation','cashFlow','flow')},
     'reviewApproval':{'status':'independently_checked','checkedAt':'2026-11-14','auditTrail':'공식 공시 및 수급 원문과 계산 기준을 별도 재검토'}}

class TestGate(unittest.TestCase):
 def test_accept_valid(self):self.assertEqual(validate_candidate(fixture(),now=NOW),[])
 def test_quota(self):
  rows=[fixture(str(i).zfill(6),'media') for i in range(1,4)]+[fixture('000004','independent'),fixture('000005','independent')]
  self.assertEqual(select_2plus1(rows,now=NOW)['counts'],{'media':2,'independent':1})
 def test_old_dedupe(self):self.assertEqual(select_2plus1([fixture()],['KR:000001'],now=NOW)['counts']['media'],0)
 def test_duplicates_across_groups(self):
  self.assertEqual(sum(select_2plus1([fixture(),fixture(type='independent')],now=NOW)['counts'].values()),1)
 def test_block_missing_cashflow(self):
  f=fixture();f['riskReview']['cashFlow']['status']='unknown';self.assertIn('unverified_cashFlow',validate_candidate(f,now=NOW))
 def test_block_old_flow(self):
  f=fixture();f['riskReview']['flow']['asOf']='2026-10-01';self.assertIn('unverified_flow',validate_candidate(f,now=NOW))
 def test_block_fake_official(self):
  f=fixture();f['officialEvidence']['url']='https://example.org/fake';self.assertIn('official_evidence_not_verified',validate_candidate(f,now=NOW))
 def test_block_no_independent_audit(self):
  f=fixture();f['reviewApproval']={};self.assertIn('independent_review_missing',validate_candidate(f,now=NOW))
 def test_block_future(self):
  f=fixture();f['sourceDate']='2027-01-01';self.assertIn('source_date_missing_or_stale',validate_candidate(f,now=NOW))
 def test_block_news_only(self):
  f={'code':'000001','name':'뉴스만','market':'KR','sourceType':'media','sourceDate':'2026-11-14'}
  self.assertEqual(select_2plus1([f],now=NOW)['counts']['media'],0)

if __name__=='__main__':unittest.main(verbosity=2)
