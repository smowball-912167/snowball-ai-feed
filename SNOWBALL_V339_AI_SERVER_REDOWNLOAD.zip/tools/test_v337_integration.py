#!/usr/bin/env python3
"""Offline end-to-end smoke test with fake public RSS; no external connection."""
from pathlib import Path
from datetime import datetime, timezone
import io, os, sys
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'automation'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ai_discovery_collector as a
from validate_v337_published_feed import validate
NOW=datetime(2026,11,13,1,0,tzinfo=timezone.utc)
RSS=b'''<?xml version="1.0"?><rss><channel>
<item><title>SKC signed supply contract</title><link>https://news.google.com/rss/abc</link><pubDate>Thu, 12 Nov 2026 01:00:00 GMT</pubDate><source>A</source></item>
<item><title>SKC begins factory production</title><link>https://news.google.com/rss/def</link><pubDate>Wed, 11 Nov 2026 01:00:00 GMT</pubDate><source>B</source></item>
</channel></rss>'''
class Response(io.BytesIO):pass
def opener(req,timeout):
    assert req.full_url.startswith('https://news.google.com/')
    return Response(RSS)
seed=[{'code':'011790','name':'SKC','market':'KR','theme':'materials','aliases':['SKC']}]
with patch.dict(os.environ,{'DART_API_KEY':'','SEC_USER_AGENT':'','KRX_API_KEY':''}):
    feed=a.scan(NOW, opener=opener, universe=seed, pause=0)
assert feed['status']=='ok'
assert feed['marketDailySummary']['status']=='NOT_CONFIGURED'
assert feed['officialNotConfigured']==1
assert feed['flowStatus']=='NOT_CONNECTED'
assert feed['verifiedRecommendations']==[]
assert validate(feed,now=NOW)==[],validate(feed,now=NOW)
print('PASS V337: complete collector -> track builder -> safety validator, all without API keys')
