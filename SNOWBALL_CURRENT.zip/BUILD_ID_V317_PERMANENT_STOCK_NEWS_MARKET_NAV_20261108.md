# V317 · Stock news panel persists through chart rerenders (2026-11-08)

## Real-device regression reported from V316
- Hanon Systems articles initially present; changing chart stock to Samsung SDI destroys the entire news/disclosure card while the AI monthly recommendations card appears.
- Previous fixes focused on filter/cache and did not address the structural deletion of the card.

## Confirmed source defect
- `window.__SNOWBALL_RENDER_SHORT` renders the short main page via `#pageShort > .app.innerHTML=...` on stock changes.
- `ntv305_short_news.js` used to insert `#ntv305ShortNews` immediately after `.v31-chartcard`, inside the subtree that gets wiped by the above rerender.
- `ntv300_ai_monthly.js` likewise mounted relative to the transient news/chart node.

## Implemented
- Both cards now mount under a new persistent sibling `#ntv317AfterChart` immediately after `#pageShort > .app`.
- The news card remains first and AI recommendations second. Unchanged account/trade/news-cache and article reader behavior.
- Mobile market outer padding and vertical spacing tightened, without viewport zoom.
- Bottom nav `액션벨` visible text changed to `액션`; symbols reduced without shrinking touch targets.
- Voice dock AI대화 and 선택읽기 buttons use 34px height with equal bottom alignment.
- Master manual root, asset, and in-app full text checked identical; S1 manifest hashes updated.

## Verification
- Playwright minimal DOM using real ntv300 and ntv305 scripts: cards remain mounted before/after chart app innerHTML rebuild, after stock sync to 006400 and after AI refresh; no JS page errors.
- JS syntax checks and manifest SHA-256 consistency.
- NOT verified: end-to-end APK on Galaxy or real news source delivery. Device feedback still required.

### Final market border adjustment
All-four-edge market density: outer main padding top 3px, sides 4px; card padding 9px on all sides; card gap 5px. Bottom content safety padding kept. No zoom/scale change.
