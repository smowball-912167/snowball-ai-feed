# V360 watch-news / home / theme corrections

- Same registry semantics in chart interest picker and stock news picker, including unclassified registered watch candidates. No localStorage writes.
- Removed orphan V356 manual-update section outside body that rendered on HOME. Preserved historic master guide inside the actual guide.
- Theme entry now calls the existing 45-minute-throttled public-feed refresh; theme observational display surfaces source generation UTC time / error detail.
- Confirmed leaders still zero because remote source lacks five market gates; no false positives or promises.
- Version 6.0.8-r9-v360 / versionCode 60436.
- Unverified: Android signed APK real-device, remote-feed runtime.
