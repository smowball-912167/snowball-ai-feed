# V301 · Recommendation individual deletion and retention
- Per-stock only: deleting a recommendation removes its card, theme, financial summary, horizon, explanation and references everywhere recommendations are displayed.
- All other recommendations persist across month changes. Deleted recommendations remain hidden across reloads and months, including old V300 month-scoped deletions.
- The previous bulk-delete button is removed. Monthly target counts only new recommendations added this month.
- Does not change holdings, trade ledger, watchlists, or upstream article data.
- Keep V299/V300 other features unchanged; Galaxy APK install is not tested.
