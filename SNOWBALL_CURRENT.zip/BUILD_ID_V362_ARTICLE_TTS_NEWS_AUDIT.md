# V362 — User-requested article speech pause/resume and access-audit

- New Android native article utterance state tracks last TTS chunk and word range start. The article action toggles 읽기 중지 / 계속 읽기. Closing reader, switching article or starting a different read resets this state.
- Article header has an expandable 기사 접근·최신화 진단 recording the last actual extraction check, number of obtained characters, access classification and latest 80 checks in localStorage. This log is derived from the user's own device checks only, not a claim about all published articles or background scraper success.
- The native WebView extraction detects explicit structured-data `isAccessibleForFree:false` or visible paywall markup and returns `paywallDetected`. Neither a subscription banner nor an extraction failure is assumed to prove paywall status. Paywalled bodies are not circumvented.
- V361 theme TOP3 scoring display and existing 3-year theme layout remain unchanged. Actual public feed failures and missing 3-year verified capex/order data remain unresolved and require separate server work.
- VersionCode=60438 / versionName=6.0.8-r9-v362 / top badge V60.8 · V362.
- Browser mocked news tests and source checks do not establish Android signed build, installed app functionality, or production news network success. Do not delete user data or change existing signing identity.
