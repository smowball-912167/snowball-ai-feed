# V366 · 2026-11-28 · V365 baseline / 14-request review
versionCode 60442; versionName 6.0.8-r9-v366; app badge V60.8 · V366.

| # | Requested item | Source result and remaining limit |
|---|---|---|
| 1 | Read speed | Restore multi-word phrasing instead of V365 isolated words; unchanged saved language-specific tuning. Actual Samsung cadence unverified. |
| 2 | Resume without skipping | Completed contiguous phrase checkpoints; replay five preceding words and the entire unfinished phrase, so more than five words may repeat. Native sound callback timing remains device-specific. |
| 3 | Korean/English | Preserve independent profiles and rates; do not reset user preferences. |
| 4 | TOP3 themes | V365 no-floor server ranking retained; old server's partial media score explicitly distinct. Separate remote server deployment and full-market data still required. |
| 5 | AI candidate pipeline | Correct long-title evidence equality (legacy 200-character truncation supported only by original unique URL/publisher match), retain 12 evidence rows, no diagnostic stock in actual AI picker, cached actual preliminary 2+1 candidates. Full final verified recommendation pipeline remains blocked by independent financial/valuation/flow evidence and remote deployment. |
| 6 | Oversold quality/value | Actual KRX observed close data when available: cap >= KRW 1T, one day <= -5% or two sessions <= -8% (provisional rule). No claim of quality/undervaluation or US price coverage. Financial and valuation inputs still needed. |
| 7 | KOSPI/KOSDAQ intraday | Reuse approved native market transport, 60s visible refresh and app resume, per-index quote timestamp, stale data identified, old last-good retained on partial error. Provider delayed quotes possible; no exchange real-time entitlement. |
| 8–10 | Watch/AI news/automatic news | Per-stock keys; selected stock refresh on route/foreground, at most one additional watch/AI stock per minute in round-robin, bounded concurrency; failure preserves prior article timestamp. No guarantee of full-text or source article availability. |
| 11 | Flicker | Avoid identical HTML rewrites of compact AI pick and stock news panels. Prior HOME/market optimizations retained; Galaxy flicker unverified. |
| 12–14 | Six buttons, navigation/subwindows, redundant UI | Existing V357–V365 fixes preserved; browser repeated navigation smoke passed. Actual device alignment and all interactions unverified. |

No signed APK produced or installed here. Public server sources under PUBLIC_AI_SERVER_DEPLOY must be separately applied to existing server repository; no new workflow, no actual server deployment in this turn. Preserve the app package/signing config and the existing local ledger, holdings, watchlists, voice settings. No forced recommendation or test rows in release data. Tests use in-memory fixtures only.
