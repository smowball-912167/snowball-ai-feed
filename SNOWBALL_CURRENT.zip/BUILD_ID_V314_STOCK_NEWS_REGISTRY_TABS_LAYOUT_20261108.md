# V314 correction / 2026-11-08

## Root causes and precise scope
- Previous V313 renamed hidden alternate .canon-nav and .bottom .navbtn, but actual mobile nav is #mainNav label[for]. Fixed real nav four labels; routes unchanged.
- ntv305_short_news.js options registry/recommendations events silently reset the selected news stock and only called render, not acquire. Initial/periodic option-list changes could similarly leave zero search calls. Fixed all entry paths to acquire current stock, with no fabricated news.
- For unanswered/error results distinguish sources and allow on-demand retries; diagnostics exposed via NOONTANGI_V305_SHORT_NEWS.diagnostic(). Existing KR 30/90/180 & Global 90/180 verification unchanged.
- Theme/tech common top button target 36 CSS px, theme cards and article gaps compressed. Chart stock chooser row height increased, no zoom.
- HOME/market edge width trimmed; no negative margins or scale transformations.
- News article actions 3 columns 2 rows, 46px buttons: original view/read/stop + translated view/read/refresh. Translated read only after verified translation text, never original fallback.
- Master V70 full text embedded exactly into app and standalone master; no preexisting history deletion.
- New runtime badge V314 to distinguish from legacy V121 voice baseline on installed app.
- Mock-feed tests must not be represented as successful public news network retrieval.
