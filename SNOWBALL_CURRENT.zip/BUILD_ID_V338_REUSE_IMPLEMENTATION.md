# V338 - actual legacy collection reuse and runtime safety

- Rebased on actual full `SNOWBALL_V336_SOURCE_QA.zip` source, then V337 server observational additions; V336 stock-flow collector JS unchanged and pinned by SHA256 in `source_registry_v338.json`.
- The Android source contains a new read-only public-market flow exporter and native user-approved share. No APK was built, signed, installed or uploaded to any repository.
- Server module `automation/legacy_flow_reuse.py` accepts ONLY previous app aggregate cache exports and explicitly makes ZERO NAVER/TOSS/KRX flow requests. Exposure to public GitHub gated on a verified license authorization variable.
- Master manual synced byte-exact into app assets and embedded guide; release gates and tests run offline.
- GitHub `snowball-ai-feed` V336 remains untouched pending installation approval and source permissions.
