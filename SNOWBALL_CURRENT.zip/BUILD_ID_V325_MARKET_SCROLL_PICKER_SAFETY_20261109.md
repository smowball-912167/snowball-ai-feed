# V325 / 2026-11-09

- Fix market content clipped behind fixed symbol; market-only scroll viewport from banner bottom +8px to nav top.
- Chart picker star control removed; registration/deletion belongs to settings; account/trade data untouched.
- Interest list omits ETF also held in pension (display-only), preserving watch registry and pension assets.
- Registry takes precedence over stale legacy favorites after removal in settings.
- Failed stock manually reselected requests a fresh search without automatic timers; live Galaxy RSS still not verified.
- Real CSS in 360/390/412px: header 134px, market top 142px, nav top / market bottom 730px, market internal scroll retains viewport clipping.
- versionCode 60402 / versionName 6.0.8-r9-v325
