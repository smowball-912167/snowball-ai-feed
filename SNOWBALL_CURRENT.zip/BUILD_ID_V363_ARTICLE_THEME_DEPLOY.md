# V363 · Android TTS and public theme scorer integration

- Stops Android TTS synchronously on bridge command before UI queue delay. Keeps onRangeStart word-position resume and reset semantics; perfect audio-sample precision is NOT guaranteed.
- Public theme scorer now receives original evidence and optional marketDaily rather than reduced UI projection. The score uses only verified available factors and never invents missing KRX flow/index/breadth/CAPEX.
- Adds public server per-scan ranking history and provisional watch rankings beyond TOP3. Server repository still must be deployed separately.
- Android app can show partial, explicitly 10/100 media-only score for legacy public feed; no fabricated index/flow points and no automatic claims of 3yr winners.
- Public feed retry against fixed GitHub API read-only host only for raw feed transport/JSON failure; DNS, TLS, invalid JSON separated. No private portfolio data.
- Version 60439/6.0.8-r9-v363. ZIP includes no signing credentials and does not modify user ledger.
- Confirmed: local Python/JS and integrity tests. Not confirmed: Android APK build, Galaxy exact speech resume, public server rollout, complete 100-point market-leading scores.
- V363 external-source ownership review: `automation/source_registry_v338.json` explicitly authorizes exactly `raw.githubusercontent.com` and `api.github.com` in existing Android feed transport, for the same hard-coded public repository and feed file; fixed path, HTTPS, no credentials or user data, no second collector. Public GitHub API rate limits are acknowledged. Original app source audit remains active.
