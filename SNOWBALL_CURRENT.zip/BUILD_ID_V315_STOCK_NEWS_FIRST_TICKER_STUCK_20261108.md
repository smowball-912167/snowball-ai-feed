# V315 selection priority correction (2026-11-08)

Problem: Initial chart auto-follow and 3-second poll can compete with explicit news-stock choice, while 30/45-second failed and empty result TTL generates repeated refresh. Replaced with selection owner and session-scoped one-shot fetch, chart follows only explicit chart change, preserved per-stock cache and identity filtering. Visible counts distinguish received vs verified title/snippet. Manual refresh only.

Verified browser mock cases, not real Android RSS.
