# V297: Market modal/summary regression repair
- Base: verified V296 source ZIP; no account data removal.
- Remove 1 redundant macro-news detail entry; omit 2 repeated unverified-news placeholder sentences (KR and US), retain verified analysis.
- Score dialog takes Android Back priority, closes to prior market route, restores focus.
- Score/dialog UI safe area sizing and scrolling; floating diagnostics and AI voice dock hidden while dialog active.
- Six market axes show five labels and matching red/orange/yellow/lightgreen/green thresholds (0-19/20-39/40-59/60-79/80-100); underlying numerical scores unchanged.
- Master manual and in-app guide updated identically.
- Native device verification pending.
