# V321 / 2026-11-08
- 사용자 승인: 시장 화면 최상단과 눈탱이 배너 사이 작은 공간. 시장 main.container padding-top only from 3px to 8px for phone width <=820px.
- 좌우 테두리, 내부 카드 레이아웃, 모든 메뉴/아이콘 크기, 뉴스 검색/필터링 JS/Java 변경 없음.
- 삼성SDI 등 종목 뉴스 0건 재현 증언은 미해결로 유지함. 이번 레이아웃 빌드만으로 해결 주장하지 않음.
- VersionCode 60398; source SHA and master guide synchronized.
