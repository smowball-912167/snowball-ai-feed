# V298 · Korean news headline parity + battery UI simplification
- Base V297 source ZIP; original title retained for native article verification and English original reading.
- Old/new theme headlines: no first-8 limit; lazy visible titles translated one at a time, persisted in existing cache.
- Original in-app article reader: Korean title translated independently of body retrieval, cached, used in Korean speech.
- Removed green solid-state caption and large detailed spotlight card; retained priority, filters and old ESS articles.
- Floating AI/speech buttons same bottom baseline, height 34px, reduced vertical padding.
- Verified: syntax/manifest/ZIP integrity only. Real publisher body access and Android device speech unverified.
