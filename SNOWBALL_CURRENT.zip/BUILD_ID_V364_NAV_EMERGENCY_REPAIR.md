# V364 · 메인/하위 메뉴 먹통 긴급 복구

- 확인된 근본원인: V363 `index.html`의 첫 `ntv69-stability-bootstrap` JS 스크립트에 `nt293FullMasterManual` HTML이 잘못 삽입됨; 첫 JS를 검사하면 `SyntaxError: Unexpected token <` 발생. `<script type=text/plain>`이 정상위치(앱 끝부분)가 아닌 초입에 들어감.
- V362 정상 index 구조로 되돌리고 V363의 리더 TTS/AI 테마/서버 개선은 개별 파일로 보존. 내장 매뉴얼은 실제 `text/plain` 스크립트에, 정상 JS 닫힘태그 바깥에 배치. 문법 및 메뉴 DOM 검사 통과 전 배포 금지.
- 기존 사용자 계좌/거래 원장/앱 패키지명/서명키 무변경. 기존 APK 제거하지 말고 덮어설치.
- versionCode 60440 / versionName 6.0.8-r9-v364.
- 한계: 자동 APK 빌드, 안드로이드 실기기 반복 클릭은 현재 작업환경에서 미검증. 이 패키지는 원인 확인된 구문 오류 복구에 집중하며 테마 서버 별도 배포는 하지 않았음.
