# V322 / 2026-11-08
- searchStockNews -> NOONTANGI_STOCK_NEWS_RESOLVE; legacy bridge fallback.
- Stock results include per-stage native received counts and filter counts.
- Exactly one automatic first-select search; no short-interval retry polling.
- Market top fixed banner has 8px visible separation while scrolling.
- UI and account data preserved; market and theme shared searchNews untouched.
- Galaxy RSS outcome pending.
