# V345 GitHub build #572 source identity correction

- Error observed: `Source integrity mismatch: app/src/main/assets/index.html`.
- Recomputed SHA-256 values for all modified release-identity assets and preserved exact-file validation.
- Aligned Android Gradle version 60421 / 6.0.8-r9-v345 and S1 manifest; advanced AI feed JS cache keys to 345 and displayed build badge to V345.
- Included existing raw.githubusercontent.com feed endpoint in approved read-only external host registry without disabling unreviewed-host guard.
- Re-synchronized the embedded master manual and the standalone guide.
- No changes to account balances, trades, or installed APK. Actual GitHub build and phone install remain to be tested.
