# V299 · Reader overlay / short-term picker regression
- Base V298 app files; account data, portfolio, signing certificate logic and market calculation unchanged.
- Reader appears below the fixed app banner and above other market-news detail overlays; title/action row no longer hidden by app shell.
- Existing Market News `읽기·번역` and `원문 보기` handlers preserved; their reader now has higher stacking priority than parent detail modal.
- Short-term picker accepts 6-character alphanumeric ETF codes (e.g. 0005D0/0038A0/0132H0/0072R0/0167A0) in pension and IRP; previously it filtered these out.
- Picker's list becomes shrinkable and vertically scrollable; touchmove outside the list no longer scrolls the main chart behind it.
- Master manual synchronized with in-app manual iframe and manifest updated.
- Real Android device scroll and publisher content availability still require field validation.
