# V300 · AI monthly candidates, chart card and settings removal
- Based on V299, preserves V299 reader/picker fixes.
- V200 validated evidence candidate ceiling raised from 1 to 8. This is a maximum, NOT a promise: no unverified picks are manufactured to hit the user target of at least two per calendar month.
- Chart-adjacent short-term AI recommendation panel; monthly local archive, short/long review flag, theme, key financial fields with missing-data disclosure and source/date evidence.
- No live financial feed exists in this build; numbers appear only when an explicitly verified recent source is present in ntv300_verified_financials_v1. All missing values show 확인 필요.
- Settings account pane offers per-item and current-month recommendation deletion with same-month suppression; never touches actual holding/transactions/watchlist.
- No auto trade or background screening promised. Actual Android install/readers remain unverified.
