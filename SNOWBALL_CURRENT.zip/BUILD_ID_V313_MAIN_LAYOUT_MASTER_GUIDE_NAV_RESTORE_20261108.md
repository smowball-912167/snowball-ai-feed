# V313 · 기준 소스 오전 10:44 비교 및 복구 (2026-11-08)

- 이전: SNOWBALL_CURRENT(20261107-104419).zip / 최신: V312_BUILD_FIX.
- 390px 모바일 렌더링에서 이전 body padding=0 / 현재 오류 body padding=20px, content x=20px, 20px overflow.
- 원인: nt293-guide-original-sync가 standalone master HTML을 innerHTML에 그대로 주입해 매뉴얼 내부의 body 스타일을 앱 전체에 적용.
- 해결: DOMParser로 master HTML의 본문만 가져오고 해당 본문 전역 style, script, link, base를 제외해 기존 guide 텍스트/항목을 동일하게 표시. 기존 screen scale은 변경하지 않음.
- ETF 안내는 뉴스 UI에서 제외, 매뉴얼에만 유지.
- 메인 메뉴 명칭: HOME→현황판, 시장환경→시장, 테마성장→테마, 기술분석→분석. 기존 JS 라우팅 구조는 그대로 유지.
- V311/V312 관련 수정사항 및 투자 데이터·뉴스 연결 경로는 유지.
- 갤럭시 실제 렌더링·기사 서버 실측 성공은 미검증.
