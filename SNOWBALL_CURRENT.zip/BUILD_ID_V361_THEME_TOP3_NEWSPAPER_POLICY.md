# V361 · THEME TOP 3 scoring and newspaper policy

- Top three from observed themes regardless of their absolute score, using a transparent independent 100-point rubric; do not reuse market-score value.
- Server scorer: `automation/theme_rank_v361.py`. `rankedThemesTop3` in `analysisTracks`, original `confirmedLeaders: []` remains unchanged.
- Missing index, investor flows, breadth, financial content are unverified and score 0, explicitly disclosed; only source-backed newspaper metadata and optional valid KRX turnover rank are scored.
- Android side transports the scored rows and renders up to three without minimum threshold, with fallback `점수 미수신` on the previous server feed.
- 2nd/3rd theme follow-up preference and 3-year growth evaluation criteria added; 3-year live automated forecast remains unverified.
- News strategy: discover paid/free metadata, diagnose access, cross-check public sources; no paid fulltext bypass or new news license implemented.
- `PUBLIC_AI_SERVER_DEPLOY` is a separate deployment bundle; current Android GitHub ZIP does not directly update a previously deployed server repository.
- This release has not been signed or installed on Galaxy and is not confirmed to receive the new server result until public server deploy.
