# V336 서버 실제 가동을 위한 실행 순서

이 문서는 **서버 전용 ZIP**에만 해당합니다. 전체 앱 소스와 개인 투자 기록, 서명키, 계정 자료는 공개 저장소에 올리지 마세요.

1. GitHub의 공개 데이터 전용 저장소에 `SNOWBALL_V336_PUBLIC_FEED_SERVER_ONLY.zip`을 **압축 해제해서 나오는 폴더 구조 그대로** 업로드합니다. `.github/workflows/`를 포함해야 합니다. 기존 `Snowball-apk` 저장소가 비공개라면 공개로 바꾸지 말고 별도 공개 저장소를 쓰세요.
2. 저장소의 **Settings → Actions → General → Workflow permissions**가 결과 파일을 커밋할 수 있도록 `Read and write permissions`인지 확인합니다(정책에 따라 제한될 수 있음). `Settings → Secrets and variables → Actions`의 `DART_API_KEY`, `SEC_USER_AGENT`는 필요한 경우 GitHub Secret으로만 설정하고 파일에 적지 않습니다.
3. **Actions → Snowball public-news AI scouting feed → Run workflow**로 최초 실행한 다음 `docs/ai_discovery_feed.json`이 200 응답으로 열리고 `status`가 `ok`/`partial`/`error` 중 하나이며 `generatedAt`이 실제 실행 시각으로 바뀌었는지 확인합니다. `not_started`라면 자동 수집이 아직 실행된 것이 아닙니다.
4. 앱 `분석 → AI 자동 탐색 → 자동 검색 연결 설정`에서 다음 형태의 **공개 저장소 실제 주소**를 등록합니다. `https://raw.githubusercontent.com/<owner>/<repo>/main/docs/ai_discovery_feed.json`.
5. **현재 주도테마 화면**에서 `공개 AI 수집 연결 → 결과 확인` 버튼을 누르고 마지막 수집 시각·검색 성공 건수·오류 이유를 확인합니다. 실제 Android 앱의 이 기능은 **V336을 기존 서명키로 빌드해 설치해야만** 표시됩니다.

## 보안·판정 주의사항

- V336 소스에는 이전 Render 서비스에 연결된 `smowball-912167/Snowball-apk` 주소가 기본 연결 *후보*로 설정되어 있습니다. 존재/공개 여부가 확인되지 않았으며, 해당 저장소가 비공개라면 주소를 새 공개 전용 저장소 URL로 직접 바꾸세요.
- 404는 파일 배포/공개 문제이지, 후보가 없다는 뜻이 아닙니다.
- GitHub Actions는 스케줄을 정의해도 정확한 시각/성공을 보장하지 않습니다. 실행 기록과 마지막 성공 여부를 검증해야 합니다.
- 현재는 24개 대표종목의 뉴스·공시 **관찰** 단계입니다. 외국인·기관 수급/재무·거래대금의 정식 데이터 확인 전에는 주도테마 또는 AI 추천 확정이 아닙니다.
- 설치된 V332/V121 등 기존 앱은 삭제하지 마세요. 기존 버전의 APK 서명 인증서가 없으면 덮어쓰기 빌드를 시도하지 마세요.
