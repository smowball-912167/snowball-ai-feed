# SNOWBALL V335 공개 AI 뉴스·공시·3항목 관찰 수집기

**이 ZIP만 별도 공개 GitHub 저장소에 업로드**하세요. V335 전체 소스·개인 보유종목·계좌 정보·빌드 서명키는 절대 공개하지 마세요.

## 실행 방법

1. 별도 GitHub 저장소를 만들고 이 ZIP의 폴더 구조(`automation/`, `docs/`, `tools/`, `.github/`)를 그대로 넣습니다.
2. GitHub **Settings → Secrets and variables → Actions**에서 필요 시 다음 Repository secrets를 설정합니다.
   - `DART_API_KEY`: 본인이 발급받은 금융감독원 OpenDART 40자리 API 인증키. 한국 공시 조회용.
   - `SEC_USER_AGENT`: SEC 이용 정책에 맞춰 요청자 이름과 실제 연락처가 담긴 식별값. 예: `Your Research Team <YOUR_EMAIL>` (예시는 실제 이메일로 대체; 저장소 파일에 직접 넣지 말 것).
3. **Actions → Snowball public-news AI scouting feed → Run workflow**를 수동 1회 실행하여 실행 권한, API 응답 및 오류 상태를 확인합니다.
4. 생성된 `docs/ai_discovery_feed.json`에서 `generatedAt`·`status`·`completed`뿐 아니라 `officialChecked`, `officialNotConfigured`, `officialFilingCount`를 확인합니다. `not_started`는 미실행입니다.
5. 정상 작동하면 Actions 스케줄이 한국 시간 08:00/13:00/19:00 부근에 실행을 시도합니다. GitHub는 정확한 시작시각·항상 성공을 보장하지 않습니다.
6. **V335 동일 원본 서명으로 빌드한 APK**의 `단기투자 → AI 추천종목 → AI 자동 탐색 · 서버 연동` 화면에 다음 실제 주소를 넣습니다.
   `https://raw.githubusercontent.com/<owner>/<repo>/main/docs/ai_discovery_feed.json`

## 중요한 제한 사항

- 공개 뉴스 조사 범위는 국내 16·미국 8개 대표종목입니다. 전 시장 탐색·실시간 감시가 아닙니다.
- 공식 공시는 **존재와 접수 여부를 확인하는 단계**이며 내용의 호재 판단이 아닙니다. 금융감독원 OpenDART는 `corpCode.xml`의 공식 고유번호로 6자리 주식코드와 대조하고, SEC는 회사 CIK를 공식 조회합니다.
- OpenDART 인증키나 SEC 식별값이 없거나 오류가 발생하면 상태를 `not_configured` 또는 `error`로 표시합니다. 이 경우 **공시가 없다**고 판단하지 않습니다.
- 외국인·기관·연기금 종목별 3~5거래일 수급, 거래대금, 재무, 선반영도는 여전히 미연동입니다. 공식 데이터 취득·사용 권한과 분석 로직이 확보되기 전까지 **검증 추천을 자동 생성하지 않습니다**.
- `verifiedRecommendations`는 서버 프로그램에서 언제나 `[]`입니다. ChatGPT 오전 8시 별도 자동화 결과와 자동 동기화되지 않습니다.
- `docs/` 출력은 공개 자료만 포함합니다. 개인 API 키/연락처/투자원장은 결과 파일이나 로그에 출력되지 않습니다. SEC 식별정보는 요청 헤더에만 사용됩니다.
- GitHub 원격 업로드 및 Actions 활성화가 완료되지 않았다면 **앱을 종료한 뒤 검색이 자동 실행되고 있다고 주장할 수 없습니다**.
- 기존 갤럭시 V332 앱은 삭제하지 마세요. 복원된 소스와 원본 서명키로 빌드한 설치본의 호환성 및 보유 데이터 보존은 실기기 별도 검증이 필요합니다.

공식 문서:
- 한국 OpenDART 공시검색: https://opendart.fss.or.kr/guide/detail.do?apiGrpCd=DS001&apiId=2019001
- 한국 OpenDART 기업 고유번호: https://opendart.fss.or.kr/guide/detail.do?apiGrpCd=DS001&apiId=2019018
- 미국 SEC API: https://www.sec.gov/edgar/sec-api-documentation
- 한국거래소 데이터 이용 안내: https://openapi.krx.co.kr/contents/OPP/DATA/OPPDATA003.jsp

## V335 추가: 3개 항목 통합 관찰
- 서버 출력 `analysisTracks`(`snowball.analysis_tracks.v1`)은 **최근 주도테마 관찰**(`leaderThemes`), **1년 후 예비후보 1차 관찰**(`oneYearWatch`), **AI 추천 심사 대기**(`aiReviewQueue`)를 동시 생성합니다.
- `confirmedLeaders`, `confirmedOneYearCandidates`, `verifiedRecommendations`는 현재 모두 빈 목록입니다. 거래대금·외국인/기관 3~5일 수급·공시 내용·재무·산업 확산·선반영도 확인이 없으므로 자동 승격하지 않습니다.
- 생성된 관찰 목록은 **전 시장 조사 결과가 아니며**, 한국 16개, 미국 8개 공개 뉴스 선별 표본 범위입니다.
- 기존 V334 서버용 ZIP을 쓰면 V335 분석 화면의 서버 기능이 일부 비어 보일 수 있습니다. V335 전용 서버 파일을 배포하고 실제 성공 실행을 확인해야 합니다.
- 서버에 개인 투자원장 및 API 키를 올리지 마세요. 버전/서명 검증이 된 V335 APK만 기존 앱 덮어쓰기 검토 대상으로 삼으세요.

## V336: 앱 연결 진단과 서버 실행 검사
- 서버 ZIP에는 `tools/validate_v336_published_feed.py` 및 GitHub Actions 자동 검사 포함. 실패한 검색은 ‘후보 없음’으로 간주하지 않고 수집 상태 `error`로 진단.
- Actions가 성공적으로 결과를 만든 뒤 `docs/ai_discovery_feed.json`이 공개 다운로드 가능해야 앱에서 수신 가능.
- V336 앱은 과거 Render 연동 저장소 주소를 **기본 연결 시도 대상으로만** 기억함. 해당 GitHub 저장소가 비공개라면 절대 공개로 전환하지 말고 공개 데이터 전용 저장소를 별도 만들 것. 앱의 `분석 → AI 자동 탐색 → 자동 검색 연결 설정`에서 공개 저장소의 JSON 주소로 변경 가능.
- 오류 404는 피드가 없거나 저장소가 공개되지 않았다는 뜻이며 AI 검색 후보 부족을 의미하지 않음.
- 마스터·앱 가이드 원문 동기화, 서명키·원장·이력 보호, 미검증 후보 승격 금지 유지.
