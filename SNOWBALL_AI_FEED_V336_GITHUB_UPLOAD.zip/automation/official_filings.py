#!/usr/bin/env python3
"""Official filing *observation* for SNOWBALL. No investment advice or recommendation.

Sources: FSS OpenDART and US SEC EDGAR. Filing existence != business progress.
All requests use fixed official hosts; API credentials stay in environment variables.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from io import BytesIO
import json
import os
import re
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import zipfile
import xml.etree.ElementTree as ET

DART_CODE_URL = "https://opendart.fss.or.kr/api/corpCode.xml"
DART_LIST_URL = "https://opendart.fss.or.kr/api/list.json"
SEC_TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
SEC_SUBMISSIONS = "https://data.sec.gov/submissions/CIK%010d.json"
SEC_FORMS = {"8-K", "10-K", "10-Q", "20-F", "6-K", "8-K/A", "10-K/A", "10-Q/A"}
DART_ACCESSION = re.compile(r"^\d{14}$")
SEC_ACCESSION = re.compile(r"^\d{10}-\d{2}-\d{6}$")
SEC_DOC = re.compile(r"^[A-Za-z0-9_.-]{1,150}$")


def _request(url, *, opener, agent, limit=4_000_000):
    req = Request(url, headers={
        "User-Agent": agent,
        "Accept": "application/json,application/xml,application/zip,*/*",
        "Accept-Encoding": "identity",
    })
    with opener(req, timeout=15) as res:
        payload = res.read(limit + 1)
    if len(payload) > limit:
        raise ValueError("OFFICIAL_RESPONSE_TOO_LARGE")
    return payload


def dart_corporations(key, *, opener=urlopen):
    if not re.fullmatch(r"[A-Za-z0-9]{40}", key or ""):
        raise ValueError("DART_API_KEY_INVALID")
    payload = _request(DART_CODE_URL + "?" + urlencode({"crtfc_key": key}),
                       opener=opener, agent="SNOWBALL official-disclosure-research/1.0",
                       limit=12_000_000)
    with zipfile.ZipFile(BytesIO(payload)) as z:
        entries = [x for x in z.infolist() if x.filename.upper().endswith(".XML") and not x.filename.startswith("/")]
        if len(entries) != 1 or entries[0].file_size > 40_000_000:
            raise ValueError("DART_CORPORATION_ZIP_INVALID")
        root = ET.fromstring(z.read(entries[0]))
    codes = {}
    for el in root.findall(".//list"):
        stock = (el.findtext("stock_code") or "").strip()
        corp = (el.findtext("corp_code") or "").strip()
        if re.fullmatch(r"\d{6}", stock) and re.fullmatch(r"\d{8}", corp):
            codes[stock] = corp
    if not codes:
        raise ValueError("DART_CORPORATION_MAP_EMPTY")
    return codes


def dart_filings(code, corp_code, key, now, *, opener=urlopen):
    # The mapping comes from the official corporation list (not from keyword/name matching).
    if not re.fullmatch(r"\d{6}", code) or not re.fullmatch(r"\d{8}", corp_code):
        raise ValueError("INVALID_DART_ID")
    end = now.date()
    begin = end - timedelta(days=120)
    url = DART_LIST_URL + "?" + urlencode({
        "crtfc_key": key, "corp_code": corp_code, "bgn_de": begin.strftime("%Y%m%d"),
        "end_de": end.strftime("%Y%m%d"), "page_count": "40", "sort": "date", "sort_mth": "desc"
    })
    raw = _request(url, opener=opener, agent="SNOWBALL official-disclosure-research/1.0")
    obj = json.loads(raw)
    status = str(obj.get("status", ""))
    if status == "013":  # No data
        return []
    if status != "000":
        raise ValueError("DART_API_STATUS_" + re.sub(r"\W", "", status)[:8])
    result = []
    for it in obj.get("list", [])[:40]:
        receipt = str(it.get("rcept_no", ""))
        d = str(it.get("rcept_dt", ""))
        if not DART_ACCESSION.fullmatch(receipt) or not re.fullmatch(r"\d{8}", d):
            continue
        if not (begin.strftime("%Y%m%d") <= d <= end.strftime("%Y%m%d")):
            continue
        result.append({
            "date": f"{d[:4]}-{d[4:6]}-{d[6:8]}",
            "title": str(it.get("report_nm", "공시"))[:180],
            "source": "OpenDART",
            "form": str(it.get("report_nm", ""))[:70],
            "url": "https://dart.fss.or.kr/dsaf001/main.do?rcpNo=" + receipt,
            "documentId": receipt,
        })
    return result[:5]


def sec_ticker_map(*, opener=urlopen, agent):
    raw = _request(SEC_TICKERS_URL, opener=opener, agent=agent)
    obj = json.loads(raw)
    output = {}
    for item in obj.values():
        code = str(item.get("ticker", "")).upper()
        cik = item.get("cik_str")
        if code and isinstance(cik, int) and cik > 0:
            output[code] = cik
    if not output:
        raise ValueError("SEC_TICKERS_EMPTY")
    return output


def sec_filings(code, cik, now, *, opener=urlopen, agent):
    if not re.fullmatch(r"[A-Z]{1,6}(?:\.[A-Z])?", code) or not isinstance(cik, int) or cik <= 0:
        raise ValueError("SEC_IDENTIFIER_INVALID")
    obj = json.loads(_request(SEC_SUBMISSIONS % cik, opener=opener, agent=agent))
    recent = obj.get("filings", {}).get("recent", {})
    forms = recent.get("form", [])
    dates = recent.get("filingDate", [])
    accs = recent.get("accessionNumber", [])
    docs = recent.get("primaryDocument", [])
    result = []
    start = now.date() - timedelta(days=120)
    for form, when, accession, document in zip(forms, dates, accs, docs):
        if form not in SEC_FORMS or not SEC_ACCESSION.fullmatch(str(accession)):
            continue
        if not SEC_DOC.fullmatch(str(document)): continue
        try:
            filing_date = datetime.strptime(when, "%Y-%m-%d").date()
        except ValueError: continue
        if filing_date < start or filing_date > now.date(): continue
        url = "https://www.sec.gov/Archives/edgar/data/%d/%s/%s" % (
            cik, accession.replace("-", ""), document)
        result.append({"date": when, "title": form + " 공식 제출", "form": form,
                       "source": "SEC EDGAR", "url": url, "documentId": accession})
        if len(result) >= 5: break
    return result


def _status(state, checked_at, filings=None, error=None):
    result = {"status": state, "checkedAt": checked_at, "filings": filings or [],
              "interpretation": "FILING_EXISTENCE_ONLY_NOT_VALIDATED"}
    if error: result["error"] = error
    return result


def enrich(candidates, now=None, *, opener=urlopen, environ=None):
    """Return candidates with isolated official evidence; never set recommendation flags.

    Uses two independent sources with credentials supplied at deployment.
    A retrieval error/absent source NEVER means 'no filings' or 'no investable stocks'.
    """
    environ = environ if environ is not None else os.environ
    now = now or datetime.now(timezone.utc)
    checked_at = now.isoformat(timespec="seconds").replace("+00:00", "Z")
    dart_key = environ.get("DART_API_KEY", "")
    sec_agent = environ.get("SEC_USER_AGENT", "")
    dart_configured = bool(re.fullmatch(r"[A-Za-z0-9]{40}", dart_key))
    sec_configured = bool(re.fullmatch(r".{6,120}<[^<>@\s]+@[^<>@\s]+\.[^<>@\s]+>", sec_agent))
    kr_codes, us_codes = None, None
    kr_init_error, us_init_error = None, None
    if dart_configured:
        try: kr_codes = dart_corporations(dart_key, opener=opener)
        except Exception as ex: kr_init_error = type(ex).__name__
    if sec_configured:
        try: us_codes = sec_ticker_map(opener=opener, agent=sec_agent)
        except Exception as ex: us_init_error = type(ex).__name__
    enhanced = []
    for candidate in candidates:
        item = dict(candidate)
        market, code = item.get("market"), item.get("code")
        source = "OpenDART" if market == "KR" else "SEC EDGAR"
        if market == "KR":
            configured, init_error, lookup = dart_configured, kr_init_error, kr_codes
        elif market == "US":
            configured, init_error, lookup = sec_configured, us_init_error, us_codes
        else: raise ValueError("UNKNOWN_MARKET")
        if not configured:
            official = _status("not_configured", checked_at)
        elif init_error:
            official = _status("error", checked_at, error=init_error)
        elif not lookup or code not in lookup:
            official = _status("identifier_missing", checked_at)
        else:
            try:
                filings = (dart_filings(code, lookup[code], dart_key, now, opener=opener)
                           if market == "KR" else sec_filings(code, lookup[code], now, opener=opener, agent=sec_agent))
                official = _status("ok", checked_at, filings)
            except Exception as ex:
                official = _status("error", checked_at, error=type(ex).__name__)
        official["source"] = source
        item["official"] = official
        # This is an explicit unconnected gate, not a fabricated 0 or false success.
        item["investorFlow"] = {"status": "not_connected", "source": "KRX" if market == "KR" else "licensed_market_data"}
        item["recommendationStatus"] = "not_verified"
        enhanced.append(item)
    return enhanced
