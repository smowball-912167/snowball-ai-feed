#!/usr/bin/env python3
"""Conservative three-track research summary; NEVER grants investment approval.

Input: public RSS title observations and filing-submission metadata. Without independently
verified turnover, 3-5-day flows, index contribution, breadth, CAPEX, filing contents,
financials and valuation, none of the three tracks is a confirmed leader/pick.
"""
from __future__ import annotations
from collections import defaultdict

GATES = ('turnover', 'flows', 'index', 'spread', 'macro')
GATE_KO = {
    'turnover': '증시 거래대금 순위·시가총액',
    'flows': '외국인·기관/연기금 3~5일 누적 수급',
    'index': '지수 견인·하방 방어',
    'spread': '대장주→2·3등주→부품·소재 확산',
    'macro': '글로벌 CAPEX·정책·신고가',
}


def thematic_group(theme):
    # Classification for observation display only, never proof of sector leadership.
    t = str(theme or '').lower()
    if any(x in t for x in ('hbm', '반도체', '클라우드')): return 'AI·반도체'
    if any(x in t for x in ('전력망', '전력기기')): return '전력망·전력기기'
    if any(x in t for x in ('방산', '국방', '우주')): return '우주·방산'
    if any(x in t for x in ('로봇', '자율주행')): return '로봇·자율주행'
    if any(x in t for x in ('배터리', '전고체')): return '배터리·전고체'
    if any(x in t for x in ('원전', 'smr')): return '원전·SMR'
    return str(theme or '분류 미지정')[:65]


def _brief(c):
    official = c.get('official') or {}
    filings = official.get('filings') or []
    news = c.get('evidence') or []
    return {
        'code': str(c.get('code', '')),
        'name': str(c.get('name', ''))[:90],
        'market': c.get('market'),
        'theme': str(c.get('theme', ''))[:100],
        'newsStage': c.get('stage', 'unavailable'),
        'newsMatches': int(c.get('matches') or 0),
        'officialStatus': official.get('status', 'unavailable'),
        'filingCount': len(filings),
        'sourceLinks': [
            {'url': x.get('url', ''), 'title': str(x.get('title', ''))[:160], 'date': str(x.get('date', ''))[:10]}
            for x in (news[:3] + filings[:2]) if x.get('url', '').startswith('https://')
        ],
    }


def build_tracks(candidates, generated_at):
    themes = defaultdict(list)
    seen_codes = set()
    watch = []
    review = []
    for raw in candidates:
        c = _brief(raw)
        identity = (c['market'], c['code'])
        if identity in seen_codes: continue
        seen_codes.add(identity)
        observed = c['newsStage'] == 'news_signal' or c['filingCount'] > 0
        if not observed: continue
        # A news headline is not a signed contract; a filing exists ≠ it is material.
        themes[thematic_group(c['theme'])].append(c)
        watch.append({**c,
            'status': 'observation_only',
            'futureHorizon': 'unverified',
            'requiredNext': ['거래대금 증가 추세', '외국인·기관 연속 수급', '수주·재무 내용 검증', '밸류체인 확산'],
        })
        review.append({**c,
            'status': 'review_required',
            'checks': {
                'publicNews': 'observed' if c['newsStage'] == 'news_signal' else 'insufficient',
                'filingSubmitted': 'observed' if c['filingCount'] else ('no_recent_submission' if c['officialStatus'] == 'ok' else 'unavailable'),
                'filingContent': 'not_verified',
                'financials': 'not_connected',
                'investorFlow': 'not_connected',
                'valuation': 'not_connected',
            },
        })
    leaders = []
    for name, stocks in sorted(themes.items(), key=lambda x: (-len(x[1]), x[0])):
        leaders.append({
            'theme': name, 'status': 'observation_only',
            'criteria': {key: 'not_verified' for key in GATES},
            'missingIndicators': list(GATE_KO.values()),
            'relatedStocks': stocks[:20],
            'reason': '기사 제목·공시 접수 여부만 관찰. 5대 절대 기준 미검증',
        })
    return {
        'schema': 'snowball.analysis_tracks.v1',
        'generatedAt': generated_at,
        'coverage': 'curated_public_news_seeds_KR_US_not_full_market',
        'leaderThemes': leaders[:30],
        'confirmedLeaders': [],
        'oneYearWatch': watch[:100],
        'confirmedOneYearCandidates': [],
        'aiReviewQueue': review[:100],
        'verifiedRecommendations': [],
        'counts': {'observedThemes': len(leaders), 'watchStocks': len(watch),
                   'reviewRequired': len(review), 'confirmedLeaders': 0,
                   'confirmedOneYearCandidates': 0, 'verifiedRecommendations': 0},
        'disclaimer': '관찰 단계. 뉴스 헤드라인과 공시 접수 자체는 주도테마·1년 후 성장·매수추천의 증거가 아님.',
    }
