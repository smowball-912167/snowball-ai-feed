#!/usr/bin/env python3
"""Validate PUBLIC feed produced by one run. Do not pretend that a failed scan means no opportunities.
Executed in GitHub Actions after the collector even if news endpoints fail.
"""
from __future__ import annotations
import json
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path


def validate(feed, *, now=None):
    now=now or datetime.now(timezone.utc)
    errors=[]
    if feed.get('schema') != 'snowball.ai_discovery.v1': errors.append('schema')
    status=feed.get('status')
    if status not in ('ok','partial','error'): errors.append('collector_not_executed')
    try:
        stamp=datetime.fromisoformat(feed.get('generatedAt','').replace('Z','+00:00'))
        if stamp.tzinfo is None or not now-timedelta(hours=1) <= stamp <= now+timedelta(minutes=30):errors.append('generatedAt_out_of_run_window')
    except (ValueError,TypeError):errors.append('generatedAt_invalid')
    candidates=feed.get('candidates')
    scanned=feed.get('scanned')
    if not isinstance(candidates,list) or not isinstance(scanned,int) or not 0<scanned<=300 or len(candidates)!=scanned:
        errors.append('scanned_candidate_mismatch')
        candidates=[]
    if feed.get('completed')!=sum(x.get('searchStatus')=='ok' for x in candidates if isinstance(x,dict)):
        errors.append('completed_count_mismatch')
    if status=='ok' and any(x.get('searchStatus')!='ok' for x in candidates): errors.append('false_success')
    if status=='error' and feed.get('completed')!=0: errors.append('false_total_failure')
    if feed.get('verifiedRecommendations') != []: errors.append('unreviewed_recommendation_promotion')
    if feed.get('flowStatus') != 'NOT_CONNECTED': errors.append('unauthorized_flow_verification')
    tracks=feed.get('analysisTracks')
    if not isinstance(tracks,dict) or tracks.get('schema') != 'snowball.analysis_tracks.v1':
        errors.append('tracks_missing')
    else:
        for k in ('confirmedLeaders','confirmedOneYearCandidates','verifiedRecommendations'):
            if tracks.get(k)!=[]:errors.append('unverified_'+k)
        for c in tracks.get('leaderThemes',[]):
            if c.get('status')!='observation_only' or any(v!='not_verified' for v in c.get('criteria',{}).values()):
                errors.append('leader_promoted_without_evidence')
        for c in tracks.get('aiReviewQueue',[]):
            if c.get('status')!='review_required':errors.append('review_promoted_without_evidence')
    seen=set()
    for row in candidates:
        if not isinstance(row,dict):errors.append('candidate_not_object');continue
        key=(row.get('market'),row.get('code'))
        if key in seen:errors.append('duplicate_market_code')
        seen.add(key)
        if row.get('searchStatus') not in ('ok','error'):errors.append('unknown_search_status')
    # The presence of a material data leak is a hard stop; redact secrets and accounts before publishing.
    forbidden=('DART_API_KEY','SEC_USER_AGENT','accountNumber','account_number','tradeHistory','holdings','apiKey','secretKey')
    raw=json.dumps(feed,ensure_ascii=False)
    for item in forbidden:
        if '"'+item+'"' in raw:errors.append('private_key_'+item)
    return sorted(set(errors))


def main():
    target=Path(sys.argv[1]) if len(sys.argv)>1 else Path('docs/ai_discovery_feed.json')
    try: feed=json.loads(target.read_text(encoding='utf-8'))
    except (OSError,ValueError) as error:
        print('FAIL feed_read:',type(error).__name__);return 1
    errors=validate(feed)
    for e in errors: print('FAIL',e)
    if errors:return 1
    print('PASS: schema + server execution + public-data integrity + unverified gates; status='+feed['status'])
    return 0

if __name__=='__main__':raise SystemExit(main())
