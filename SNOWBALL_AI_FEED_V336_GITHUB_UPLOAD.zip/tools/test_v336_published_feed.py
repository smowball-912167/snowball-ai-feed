import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path(__file__).resolve().parents[1] / 'automation'))
from validate_v336_published_feed import validate
from three_track_pipeline import build_tracks
now=datetime(2026,11,12,12,0,tzinfo=timezone.utc)
when=now.isoformat(timespec='seconds').replace('+00:00','Z')
row={'market':'KR','code':'011790','name':'SKC','theme':'유리기판','stage':'insufficient',
 'matches':0,'searchStatus':'ok','evidence':[],'official':{'status':'not_configured','filings':[]}}
feed={'schema':'snowball.ai_discovery.v1','generatedAt':when,'status':'ok','scanned':1,'completed':1,
 'candidates':[row],'verifiedRecommendations':[],'flowStatus':'NOT_CONNECTED','analysisTracks':build_tracks([row],when)}
assert validate(feed,now=now)==[]
assert 'collector_not_executed' in validate({**feed,'status':'not_started'},now=now)
assert 'false_success' in validate({**feed,'candidates':[{**row,'searchStatus':'error'}]},now=now)
assert 'unreviewed_recommendation_promotion' in validate({**feed,'verifiedRecommendations':[{'name':'fake'}]},now=now)
assert 'unverified_confirmedLeaders' in validate({**feed,'analysisTracks':{**feed['analysisTracks'],'confirmedLeaders':[{'theme':'fake'}]}},now=now)
assert 'generatedAt_out_of_run_window' in validate({**feed,'generatedAt':(now-timedelta(hours=2)).isoformat()},now=now)
assert 'private_key_account_number' in validate({**feed,'account_number':'unknown'},now=now)
assert 'duplicate_market_code' in validate({**feed,'scanned':2,'completed':2,'candidates':[row,row]},now=now)
print('PASS V336: success, missing, stale, false completion, private-data blockers, no unverified promotion')
