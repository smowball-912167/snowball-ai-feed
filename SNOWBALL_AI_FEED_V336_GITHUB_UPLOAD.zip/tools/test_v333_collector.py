#!/usr/bin/env python3
"""Offline mocked feed tests; no external requests or made-up live search successes."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'automation'))
import ai_discovery_collector as c
from datetime import datetime, timezone
from io import BytesIO

NOW=datetime(2026,11,11,0,0,tzinfo=timezone.utc)
RSS=b'''<?xml version="1.0" encoding="UTF-8"?><rss><channel>
<item><title>SKC signed supply contract - first report</title><link>https://news.google.com/rss/articles/one</link><pubDate>Mon, 09 Nov 2026 03:00:00 GMT</pubDate><source>Publisher A</source></item>
<item><title>SKC begins mass production at new factory</title><link>https://news.google.com/rss/articles/two</link><pubDate>Tue, 10 Nov 2026 03:00:00 GMT</pubDate><source>Publisher B</source></item>
<item><title>Wrong company wins orders</title><link>https://news.google.com/rss/articles/three</link><pubDate>Tue, 10 Nov 2026 03:00:00 GMT</pubDate><source>Publisher C</source></item>
<item><title>SKC rumored contract</title><link>https://news.google.com/rss/articles/four</link><pubDate>Tue, 10 Nov 2026 03:00:00 GMT</pubDate><source>Publisher D</source></item>
</channel></rss>'''
class Response(BytesIO): pass

def ok(_req,timeout):
    assert timeout <= 15
    return Response(RSS)

def fail(_req,timeout): raise TimeoutError('mock')

seed=[{'code':'011790','name':'SKC','market':'KR','theme':'materials','aliases':['SKC']}]
a=c.scan(NOW,opener=ok,universe=seed,pause=0)
assert a['status']=='ok' and a['completed']==1 and a['scanned']==1,a
assert a['newsSignalCount']==1 and a['candidates'][0]['matches']==2,a
assert a['verification']=='NEWS_AND_OFFICIAL_FILINGS_UNREVIEWED' and a['verifiedRecommendations']==[],a
assert len(a['candidates'][0]['evidence'])==2,a
assert a['analysisTracks']['schema']=='snowball.analysis_tracks.v1'
assert len(a['analysisTracks']['oneYearWatch'])==1 and len(a['analysisTracks']['aiReviewQueue'])==1
assert a['analysisTracks']['confirmedLeaders']==a['analysisTracks']['verifiedRecommendations']==[]
b=c.scan(NOW,opener=fail,universe=seed,pause=0)
assert b['status']=='error' and b['completed']==0 and b['candidates'][0]['searchStatus']=='error'
assert b['newsSignalCount']==0 and b['errors'][0]['type']=='TimeoutError'
assert c.matching('SKC will sign the contract',seed[0])
assert c.RUMOR.search('SKC rumored contract')
assert c.RUMOR.search('SKC rumoured contract')
assert c.RUMOR.search('SKC speculation about a deal')
assert not c.RUMOR.search('SKC signed supply contract')
assert not c.matching('SKCALK outlook',seed[0])
assert c.parse_item(__import__('xml.etree.ElementTree',fromlist=['ElementTree']).fromstring('<item><title>SKC 공급계약</title><link>http://example.com/a</link><pubDate>Mon, 09 Nov 2026 03:00:00 GMT</pubDate></item>'),seed[0],NOW) is None
print('PASS: server news filtering, dates/publishers, no recommendation, error != no candidates')
