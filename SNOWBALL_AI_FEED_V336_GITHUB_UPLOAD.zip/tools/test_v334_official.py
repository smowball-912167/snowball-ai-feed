#!/usr/bin/env python3
"""Official evidence gate tests, fully mocked; does NOT hit DART or SEC."""
from pathlib import Path
import io, json, sys, zipfile
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"automation"))
import official_filings as f
from unittest.mock import patch

NOW=datetime(2026,11,11,5,0,tzinfo=timezone.utc)
KEY="A"*40
AGENT="Snowball Research <contact@example.org>"
KR={"code":"011790","name":"SKC","market":"KR","stage":"news_signal"}
US={"code":"NVDA","name":"NVIDIA","market":"US","stage":"insufficient"}
DART_XML=b"""<?xml version="1.0" encoding="UTF-8"?><result><list><corp_code>00126380</corp_code><corp_name>SKC</corp_name><stock_code>011790</stock_code><modify_date>20261110</modify_date></list></result>"""
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,"w") as z:z.writestr("CORPCODE.xml",DART_XML)
CORP_ZIP=buffer.getvalue()

class Response(io.BytesIO):
    pass

def fake_opener(req,timeout):
    assert timeout == 15
    u=req.full_url
    if "corpCode.xml" in u:
        assert parse_qs(urlparse(u).query)["crtfc_key"]==[KEY]
        return Response(CORP_ZIP)
    if "/api/list.json" in u:
        q=parse_qs(urlparse(u).query)
        assert q["corp_code"]==["00126380"] and q["bgn_de"]==["20260714"]
        return Response(json.dumps({"status":"000","list":[
           {"rcept_no":"20261111000001","rcept_dt":"20261111","report_nm":"단일판매ㆍ공급계약"},
           {"rcept_no":"oops","rcept_dt":"20261110","report_nm":"위조 번호"},
        ]}).encode())
    if "company_tickers.json" in u:
        assert "contact@example.org" in req.headers.get("User-agent", "")
        return Response(json.dumps({"0":{"ticker":"NVDA","cik_str":1045810}}).encode())
    if "/submissions/CIK0001045810.json" in u:
        return Response(json.dumps({"filings":{"recent":{
            "form":["8-K","10-Q","S-8"],
            "filingDate":["2026-11-10","2026-10-31","2026-10-30"],
            "accessionNumber":["0001045810-26-000123","0001045810-26-000100","0001045810-26-000090"],
            "primaryDocument":["form8k.htm","report.htm","other.htm"]
        }}}).encode())
    raise AssertionError("unknown URL "+u)

env={"DART_API_KEY":KEY,"SEC_USER_AGENT":AGENT}
rows=f.enrich([KR,US],NOW,opener=fake_opener,environ=env)
assert rows[0]["official"]["status"]=="ok"
assert rows[0]["official"]["filings"][0]["source"]=="OpenDART"
assert rows[0]["official"]["filings"][0]["url"].startswith("https://dart.fss.or.kr/")
assert len(rows[0]["official"]["filings"])==1
assert rows[1]["official"]["status"]=="ok"
assert len(rows[1]["official"]["filings"])==2
assert rows[1]["official"]["filings"][0]["url"]=="https://www.sec.gov/Archives/edgar/data/1045810/000104581026000123/form8k.htm"
assert all(x["recommendationStatus"]=="not_verified" for x in rows)
assert all(x["investorFlow"]["status"]=="not_connected" for x in rows)

missing=f.enrich([KR,US],NOW,opener=fake_opener,environ={})
assert [x["official"]["status"] for x in missing]==["not_configured","not_configured"]
assert all(x["official"]["filings"]==[] for x in missing)

def broken(req,timeout):raise TimeoutError("network blocked")
errors=f.enrich([KR,US],NOW,opener=broken,environ=env)
assert [x["official"]["status"] for x in errors]==["error","error"]
assert all(x["recommendationStatus"]=="not_verified" for x in errors)
assert all(not x["official"]["filings"] for x in errors)

assert f.SEC_DOC.fullmatch("../evil") is None
assert f.DART_ACCESSION.fullmatch("fake") is None
print("PASS V334: official identifiers, SEC/DART filings, credential gates, timeout isolation, no AI recommendation")
