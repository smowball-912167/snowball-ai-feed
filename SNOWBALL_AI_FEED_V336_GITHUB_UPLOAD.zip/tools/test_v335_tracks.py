#!/usr/bin/env python3
"""Offline tests; invented fixtures are NEVER published as real research."""
import sys
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'automation'))
from three_track_pipeline import build_tracks

now = '2026-11-12T09:00:00Z'
news = [{'title':'SKC 실제 공급계약 제목', 'url':'https://news.google.com/a', 'date':'2026-11-11'}]
filing = [{'title':'공시 접수', 'url':'https://dart.fss.or.kr/dsaf001/main.do?rcpNo=20261111000001', 'date':'2026-11-11'}]
rows = [
 {'code':'011790','name':'SKC','theme':'유리기판·첨단소재','market':'KR','stage':'news_signal', 'matches':2,'evidence':news, 'official':{'status':'ok','filings':filing}},
 {'code':'000660','name':'SK하이닉스','theme':'AI·HBM','market':'KR','stage':'insufficient','matches':1, 'evidence':[], 'official':{'status':'not_configured','filings':[]}},
 {'code':'NVDA','name':'Nvidia','theme':'AI·반도체','market':'US','stage':'news_signal','matches':4,'evidence':news,'official':{'status':'error','filings':[]}},
]
out = build_tracks(rows, now)
assert out['schema'] == 'snowball.analysis_tracks.v1'
assert len(out['leaderThemes']) == 2
assert out['counts'] == {'observedThemes':2,'watchStocks':2,'reviewRequired':2,'confirmedLeaders':0,'confirmedOneYearCandidates':0,'verifiedRecommendations':0}
assert out['confirmedLeaders'] == out['confirmedOneYearCandidates'] == out['verifiedRecommendations'] == []
assert all(x['status']=='observation_only' and all(y=='not_verified' for y in x['criteria'].values()) for x in out['leaderThemes'])
assert all(x['status']=='observation_only' and x['futureHorizon']=='unverified' for x in out['oneYearWatch'])
assert all(x['status']=='review_required' and x['checks']['investorFlow']=='not_connected' for x in out['aiReviewQueue'])
assert out['aiReviewQueue'][1]['checks']['filingSubmitted']=='unavailable'
assert out['aiReviewQueue'][0]['filingCount'] == 1
assert build_tracks([],now)['counts']['observedThemes']==0
print('PASS V335: 3 tracks, observation gates, source references, no fabricated leaders/AI picks')
